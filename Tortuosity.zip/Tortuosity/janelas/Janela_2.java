package janelas;

import ij.IJ;

import java.awt.BorderLayout;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JLabel;
import javax.swing.JProgressBar;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JTable;

import java.awt.Container;
import java.awt.GridLayout;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

import javax.swing.JScrollPane;
import javax.swing.SwingConstants;



import controle.Imagem;
import controle.PreencheGrafico;
import controle.Processar;
import controle.TabelaGeral;
import controle.ThreadCalcular;

public class Janela_2 extends JFrame {
	public JLabel labelPX;
	public JLabel labelPY;
	public JLabel labelPZ;
	private Container contentPane;

	JLabel progresso;
	public Imagem pX;
	public Imagem nX;
	public Imagem pY;
	public Imagem nY;
	public Imagem pZ;
	public Imagem nZ;
	public JButton botaoExibirPX;
	JProgressBar barraGeral;
	byte type;
	public JTabbedPane tabbedPane;
	//private static final int BYTE = 0, SHORT = 1, FLOAT = 2, RGB = 3;
	public JProgressBar progressBarPx;
	public JProgressBar progressBarPy;
	public JProgressBar progressBarPz;
	public JProgressBar progressBarNx;
	public JProgressBar progressBarNy;
	public JProgressBar progressBarNz;
	public JLabel labelNX;
	public JLabel labelNY;
	public JLabel labelNZ;
	private JButton button_1;
	private JPanel panelNX;
	private JButton button_2;
	private JPanel panelNY;
	private JButton button_3;
	private JPanel panelNZ;
	private JButton button_4;
	public JPanel StatusGeral;
	private JScrollPane scrollPane_1;
	private JScrollPane scrollPane_2;
	private JScrollPane scrollPane_3;
	private JScrollPane scrollPane_4;
	private JScrollPane scrollPane_5;
	public JTable tabelaPX;
	public JTable tabelaNX;
	public JTable tabelaPY;
	public JTable tabelaNY;
	public JTable tabelaPZ;
	public JTable tabelaNZ;
	public JTable tabelaGeral;
	public Imagem imagens[];
	public JButton btnExibirDados;
	public JPanel StatusGeralLayout;
	public int numThreadsFinalizadas=0;
	public ThreadCalcular Threads[];
private static Janela_2 uniqueInstance;	
	
	public static synchronized Janela_2 getInstance() {
		return uniqueInstance; } 

	public static synchronized void setInstance(Janela_2 instance) {
		 uniqueInstance=instance; 
		 } 

	/**
	 * Launch the application.
	 */
	/*
	 * public static void main(String[] args) { EventQueue.invokeLater(new
	 * Runnable() { public void run() { try { Proc2 frame = new Proc2(null,
	 * 128); frame.setVisible(true); } catch (Exception e) {
	 * e.printStackTrace(); } } }); }
	 * 
	 * /** Create the frame.
	 */

	
	public Janela_2() {
		super("Tortuosity");
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosed(WindowEvent e) {
				
			if(Threads!=null){
				for(int i=0;i<Threads.length;i++){
					if(Threads[i].isAlive()){
						Threads[i].interrupt();
						//IJ.log("Funcionando "+i);
					}
				}
			}
				System.gc();
				Janela_1.getInstance().setVisible(true);
				/*
				 * 
				 * Resolver o lixo visual
				 */
			}
		});
		
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		//setBounds(100, 100, 450, 300);
		contentPane = getContentPane();
		
		//contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout());
		
		Container c2=new JPanel();
		c2.setLayout(new GridLayout(1,2,4,5));

		progresso = new JLabel("New label");
		progresso.setHorizontalAlignment(SwingConstants.CENTER);
		
		

		barraGeral = new JProgressBar();
		barraGeral.setStringPainted(true);
				
		c2.add(progresso);
		c2.add(barraGeral);
contentPane.add(BorderLayout.NORTH, c2);
		tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		
		contentPane.add(BorderLayout.CENTER, tabbedPane);

		JPanel StatusGeralLayout = new JPanel();
		StatusGeralLayout.setLayout(new BorderLayout());
		tabbedPane.addTab("Status", null, StatusGeralLayout, null);
		Janela_1 janela1=Janela_1.getInstance();
		StatusGeral = new JPanel();
		StatusGeral.setLayout(new GridLayout(janela1.numDirec, 2, 4, 4));
		StatusGeralLayout.add(BorderLayout.NORTH,StatusGeral);
		//StatusGeral.setPreferredSize(new Dimension(20,20));
		if(janela1.checkMaisX.isSelected()){
		labelPX = new JLabel("+x");
		labelPX.setHorizontalAlignment(SwingConstants.CENTER);
		StatusGeral.add(labelPX);

		progressBarPx = new JProgressBar();
		progressBarPx.setStringPainted(true);
	
		StatusGeral.add(progressBarPx);
		}
		if(janela1.checkMenosX.isSelected()){
		labelNX = new JLabel("-x");
		labelNX.setHorizontalAlignment(SwingConstants.CENTER);
		
		StatusGeral.add(labelNX);

		progressBarNx = new JProgressBar();
		progressBarNx.setStringPainted(true);

		StatusGeral.add(progressBarNx);
		}
		if(janela1.checkMaisY.isSelected()){
		labelPY = new JLabel("+y");
		labelPY.setHorizontalAlignment(SwingConstants.CENTER);
		
		StatusGeral.add(labelPY);
		progressBarPy = new JProgressBar();
		progressBarPy.setStringPainted(true);

		StatusGeral.add(progressBarPy);
		}
		if(janela1.checkMenosY.isSelected()){
		labelNY = new JLabel("-y");
		labelNY.setHorizontalAlignment(SwingConstants.CENTER);
		
		StatusGeral.add(labelNY);
		
		
		progressBarNy = new JProgressBar();
		progressBarNy.setStringPainted(true);

		StatusGeral.add(progressBarNy);
		}
		if(janela1.checkMaisZ.isSelected()){
			labelPZ = new JLabel("+z");
			labelPZ.setHorizontalAlignment(SwingConstants.CENTER);
			
		StatusGeral.add(labelPZ);
		progressBarPz = new JProgressBar();
		progressBarPz.setStringPainted(true);

		StatusGeral.add(progressBarPz);
		}
		if(janela1.checkMenosZ.isSelected()){
			
		labelNZ = new JLabel("-z");
		labelNZ.setHorizontalAlignment(SwingConstants.CENTER);
		StatusGeral.add(labelNZ);
		
		progressBarNz = new JProgressBar();
		progressBarNz.setStringPainted(true);

		StatusGeral.add(progressBarNz);
		}
		btnExibirDados = new JButton("View summary data.");// (WARNING: Only click after completing all.)");
		btnExibirDados.setEnabled(false);
		
		btnExibirDados.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFrame frame = new JFrame("Summary data");

				frame.getContentPane().setLayout(new BorderLayout());
				JScrollPane scrollPane = new JScrollPane();
				//scrollPane.setBounds(10, 35, 149, 84);

				tabelaGeral = new JTable();
				tabelaGeral.setColumnSelectionAllowed(true);
				tabelaGeral.setCellSelectionEnabled(true);

				scrollPane.setViewportView(tabelaGeral);
				frame.getContentPane().add(BorderLayout.CENTER, scrollPane);
				tabelaGeral.setModel(new TabelaGeral(imagens));
				JButton buttonS=new JButton("Export .csv");
				buttonS.addActionListener(new Ouvinte());
				frame.getContentPane().add(BorderLayout.SOUTH, buttonS);
				frame.setSize(300, 300);
				frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
				frame.setVisible(true);

			}
		});
		//btnExibirDados.setEnabled(true);
		// btnExibirDados.setBounds(43, 0, 146, 23);
		StatusGeralLayout.add(BorderLayout.SOUTH, btnExibirDados);

		JPanel panelPX = new JPanel();
		tabbedPane.addTab("+x", null, panelPX, null);
		tabbedPane.setEnabledAt(1, false);
		panelPX.setLayout(new BorderLayout());

		botaoExibirPX = new JButton("Display graphics");
		botaoExibirPX.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new PreencheGrafico(pX).start();
				//pX.showGraph(pX.largura);
			}
		});
		//botaoExibirPX.setBounds(10, 153, 130, 23);
		panelPX.add(BorderLayout.SOUTH,botaoExibirPX);

		JScrollPane scrollPane = new JScrollPane();
		//scrollPane.setBounds(31, 35, 251, 84);
		panelPX.add(BorderLayout.CENTER,scrollPane);

		tabelaPX = new JTable();
		tabelaPX.setColumnSelectionAllowed(true);
		tabelaPX.setCellSelectionEnabled(true);

		scrollPane.setViewportView(tabelaPX);

		panelNX = new JPanel();
		panelNX.setLayout(new BorderLayout());
		tabbedPane.addTab("-x", null, panelNX, null);
		tabbedPane.setEnabledAt(2, false);

		button_2 = new JButton("Display graphics");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new PreencheGrafico(nX).start();
			}
		});
	//	button_2.setBounds(10, 153, 130, 23);
		panelNX.add(BorderLayout.SOUTH, button_2);

		scrollPane_1 = new JScrollPane();
		//scrollPane_1.setBounds(10, 34, 260, 84);
		panelNX.add(BorderLayout.CENTER, scrollPane_1);

		tabelaNX = new JTable();
		scrollPane_1.setViewportView(tabelaNX);
		tabelaNX.setColumnSelectionAllowed(true);
		tabelaNX.setCellSelectionEnabled(true);

		JPanel panelPY = new JPanel();
		tabbedPane.addTab("+y", null, panelPY, null);
		tabbedPane.setEnabledAt(3, false);
		panelPY.setLayout(new BorderLayout());

		JButton button = new JButton("Display graphics");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new PreencheGrafico(pY).start();
			}
		});
		//button.setBounds(36, 153, 130, 23);
		panelPY.add(BorderLayout.SOUTH, button);

		scrollPane_2 = new JScrollPane();
		//scrollPane_2.setBounds(10, 33, 267, 84);
		panelPY.add(BorderLayout.CENTER, scrollPane_2);

		tabelaPY = new JTable();
		tabelaPY.setColumnSelectionAllowed(true);
		tabelaPY.setCellSelectionEnabled(true);
		scrollPane_2.setViewportView(tabelaPY);

		panelNY = new JPanel();
		panelNY.setLayout(new BorderLayout());;
		tabbedPane.addTab("-y", null, panelNY, null);
		tabbedPane.setEnabledAt(4, false);

		button_3 = new JButton("Display graphics");
		button_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new PreencheGrafico(nY).start();
			}
		});
	//	button_3.setBounds(36, 153, 130, 23);
		panelNY.add(BorderLayout.SOUTH, button_3);

		scrollPane_3 = new JScrollPane();
		//scrollPane_3.setBounds(17, 28, 250, 84);
		panelNY.add(BorderLayout.CENTER, scrollPane_3);

		tabelaNY = new JTable();
		tabelaNY.setColumnSelectionAllowed(true);
		tabelaNY.setCellSelectionEnabled(true);
		scrollPane_3.setViewportView(tabelaNY);

		JPanel panelPZ = new JPanel();
		panelPZ.setLayout(new BorderLayout());
		tabbedPane.addTab("+z", null, panelPZ, null);
		tabbedPane.setEnabledAt(5, false);

		button_1 = new JButton("Display graphics");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//
				new PreencheGrafico(pZ).start();
			}
		});
	//	button_1.setBounds(23, 143, 130, 23);
		panelPZ.add(BorderLayout.SOUTH, button_1);

		scrollPane_4 = new JScrollPane();
		//scrollPane_4.setBounds(21, 26, 265, 84);
		panelPZ.add(BorderLayout.CENTER, scrollPane_4);

		tabelaPZ = new JTable();
		tabelaPZ.setColumnSelectionAllowed(true);
		tabelaPZ.setCellSelectionEnabled(true);
		scrollPane_4.setViewportView(tabelaPZ);

		panelNZ = new JPanel();
		tabbedPane.addTab("-z", null, panelNZ, null);
		tabbedPane.setEnabledAt(6, false);
		panelNZ.setLayout(new BorderLayout());

		button_4 = new JButton("Display graphics");
		button_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new PreencheGrafico(nZ).start();
			}
		});
		//button_4.setBounds(23, 143, 130, 23);
		panelNZ.add(BorderLayout.SOUTH, button_4);

		scrollPane_5 = new JScrollPane();
	//	scrollPane_5.setBounds(10, 37, 274, 84);
		panelNZ.add(BorderLayout.CENTER, scrollPane_5);

		tabelaNZ = new JTable();
		tabelaNZ.setColumnSelectionAllowed(true);
		tabelaNZ.setCellSelectionEnabled(true);
		scrollPane_5.setViewportView(tabelaNZ);

		setSize(450,300);
		setVisible(true);
		Janela_2.setInstance(this);
		new Processar(barraGeral, progresso).start();
	}
	
	public synchronized void threadCalcularFinalizou(){
		numThreadsFinalizadas++;
		if(numThreadsFinalizadas==Janela_1.getInstance().numDirec){
			btnExibirDados.setEnabled(true);
		}
		
		
	}
	class Ouvinte implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
int colunas, linhas;
String destino=IJ.getDirectory("Select the destination folder...");
colunas=tabelaGeral.getColumnCount();
linhas=tabelaGeral.getRowCount();
FileWriter  write ;
BufferedWriter  writer;
try {

	  write = new FileWriter(destino+"\\tortuosity.csv");
	 writer = new BufferedWriter(write);
	 for(int j=0;j<colunas;j++){
	 writer.write(tabelaGeral.getColumnName(j)+";");
	 }
	   writer.newLine();
	     
    for(int i=0;i<linhas;i++){
        for(int j=0;j<colunas;j++){
        	
        	writer.write(tabelaGeral.getValueAt(i,j).toString().replace(".",",")+";");
        }
        writer.newLine();
    }
    writer.close();
     
} catch (IOException ex) {
    System.out.println("Erro na escrita do arquivo!" + ex);

}
			
		}
		
	}
}
