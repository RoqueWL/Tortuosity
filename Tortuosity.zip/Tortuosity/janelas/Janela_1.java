package janelas;

import java.awt.EventQueue;

import ij.*;
import ij.plugin.*;
import ij.plugin.frame.MemoryMonitor;
import ij.process.ImageStatistics;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.SpringLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JLabel;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.ButtonGroup;
import javax.swing.JFormattedTextField;
import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;
import javax.swing.JComboBox;

public class Janela_1 extends JFrame implements PlugIn {
	public int limiar;
	public int EE = 6;
	public byte regiao=(byte) 255;
	private JPanel contentPane;
	private JFormattedTextField textFieldLimiar;
	public JRadioButton radioB_EE_8, radioB_EE_4 , radioB_EE_6, radioB_EE_18, radioB_EE_26, rdbtnGro, rdbtnPoro;
	
	public JCheckBox checkMaisX, checkMenosX, checkMaisY, checkMenosY,
			checkMaisZ, checkMenosZ;
	int[] pilhas;
	private RadioButtonHandler handler;
	private RadioButtonHandler2 handler2;
	private RadioButtonHandlerD handlerD;
	private RadioR handlerR;
	public JComboBox comboBox;
	public int numDirec = 0;
	public Janela_2 frame;
	public int na = 0;
	/**
	 * Launch the application.
	 */

	private static Janela_1 uniqueInstance;
	private final ButtonGroup buttonGroup = new ButtonGroup();
	private final ButtonGroup buttonGroup_1 = new ButtonGroup();
	private final ButtonGroup buttonGroup_2 = new ButtonGroup();
	private final ButtonGroup buttonGroup_3 = new ButtonGroup();

	public static synchronized Janela_1 getInstance() {
		return uniqueInstance;
	}

	public static synchronized void setInstance(Janela_1 instance) {
		uniqueInstance = instance;
	}

	public int getEE() {
		return this.EE;
	}

	public void run(String args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					// uniqueInstance = new Nova_Janela();
					// System.out.println(na);
					// IJ.log(" "+na);
					// uniqueInstance.setVisible(true);
				} catch (Exception e) {

					// TIRAR AS GRADES DO GR�FICO PARA MELHORAR A VISIBILIDADE (
					// ?? )
					e.printStackTrace();
				}
			}
		});
	}

	public static void main(String[] args) {
		ImageJ IJ1 = new ImageJ();

	}

	/**
	 * Create the frame.
	 */
	public Janela_1() {
		
		
		setResizable(false);
		// setAutoRequestFocus(false);
		
		setTitle("Tortuosity");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		SpringLayout sl_contentPane = new SpringLayout();
		contentPane.setLayout(sl_contentPane);
		handler = new RadioButtonHandler();
		handler2= new RadioButtonHandler2();
		handlerD= new RadioButtonHandlerD();
		handlerR= new RadioR();
		
		JButton ButtonHistograma = new JButton("Histogram");
		sl_contentPane.putConstraint(SpringLayout.NORTH, ButtonHistograma, 10,
				SpringLayout.NORTH, contentPane);
		sl_contentPane.putConstraint(SpringLayout.EAST, ButtonHistograma, -81,
				SpringLayout.EAST, contentPane);
		ButtonHistograma.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					WindowManager.setTempCurrentImage(WindowManager
							.getImage(comboBox.getSelectedItem().toString()));
					new Histogram().run("null");
				} catch (Exception ae) {
				}
			}
		});
		contentPane.add(ButtonHistograma);

		checkMaisY = new JCheckBox("+Y");
		checkMaisY.addItemListener(new CheckBoxListener());
		contentPane.add(checkMaisY);

		checkMenosY = new JCheckBox("-Y");
		checkMenosY.addItemListener(new CheckBoxListener());
		sl_contentPane.putConstraint(SpringLayout.SOUTH, checkMenosY, -91,
				SpringLayout.SOUTH, contentPane);
		sl_contentPane.putConstraint(SpringLayout.NORTH, checkMaisY, 6,
				SpringLayout.SOUTH, checkMenosY);
		sl_contentPane.putConstraint(SpringLayout.WEST, checkMaisY, 0,
				SpringLayout.WEST, checkMenosY);
		contentPane.add(checkMenosY);

		checkMaisX = new JCheckBox("+X");
		checkMaisX.addItemListener(new CheckBoxListener());
		sl_contentPane.putConstraint(SpringLayout.NORTH, checkMaisX, 0,
				SpringLayout.NORTH, checkMaisY);
		contentPane.add(checkMaisX);

		checkMaisZ = new JCheckBox("+Z");
		checkMaisZ.addItemListener(new CheckBoxListener());
		sl_contentPane.putConstraint(SpringLayout.NORTH, checkMaisZ, 0,
				SpringLayout.NORTH, checkMaisY);
		contentPane.add(checkMaisZ);

		checkMenosZ = new JCheckBox("-Z");
		checkMenosZ.addItemListener(new CheckBoxListener());
		sl_contentPane.putConstraint(SpringLayout.WEST, checkMenosZ, 304,
				SpringLayout.WEST, contentPane);
		sl_contentPane.putConstraint(SpringLayout.EAST, checkMenosY, -58,
				SpringLayout.WEST, checkMenosZ);
		sl_contentPane.putConstraint(SpringLayout.WEST, checkMaisZ, 0,
				SpringLayout.WEST, checkMenosZ);
		contentPane.add(checkMenosZ);

		checkMenosX = new JCheckBox("-X");
		checkMenosX.addItemListener(new CheckBoxListener());
		sl_contentPane.putConstraint(SpringLayout.WEST, checkMaisX, 0,
				SpringLayout.WEST, checkMenosX);
		sl_contentPane.putConstraint(SpringLayout.SOUTH, checkMenosX, -91,
				SpringLayout.SOUTH, contentPane);
		sl_contentPane.putConstraint(SpringLayout.EAST, checkMenosX, -68,
				SpringLayout.WEST, checkMenosY);
		contentPane.add(checkMenosX);

		textFieldLimiar = new JFormattedTextField();
		sl_contentPane.putConstraint(SpringLayout.EAST, textFieldLimiar, 120,
				SpringLayout.WEST, ButtonHistograma);
		textFieldLimiar.setText("128");

		sl_contentPane.putConstraint(SpringLayout.NORTH, textFieldLimiar, 10,
				SpringLayout.SOUTH, ButtonHistograma);
		sl_contentPane.putConstraint(SpringLayout.WEST, textFieldLimiar, 0,
				SpringLayout.WEST, ButtonHistograma);
		contentPane.add(textFieldLimiar);
		textFieldLimiar.setColumns(10);

		JLabel lblNewLabel = new JLabel("Threshold");
		sl_contentPane.putConstraint(SpringLayout.NORTH, lblNewLabel, 3,
				SpringLayout.NORTH, textFieldLimiar);
		sl_contentPane.putConstraint(SpringLayout.EAST, lblNewLabel, -23, SpringLayout.WEST, textFieldLimiar);
		contentPane.add(lblNewLabel);

		JLabel lblElementoEstruturante = new JLabel("Structure Element");
		sl_contentPane.putConstraint(SpringLayout.WEST, lblElementoEstruturante, 10, SpringLayout.WEST, contentPane);
		contentPane.add(lblElementoEstruturante);

		radioB_EE_18 = new JRadioButton("18");
		radioB_EE_18.addItemListener(handler);
		buttonGroup.add(radioB_EE_18);
		
		contentPane.add(radioB_EE_18);

		radioB_EE_6 = new JRadioButton("6");
		sl_contentPane.putConstraint(SpringLayout.NORTH, radioB_EE_18, 6, SpringLayout.SOUTH, radioB_EE_6);
		sl_contentPane.putConstraint(SpringLayout.WEST, radioB_EE_18, 0, SpringLayout.WEST, radioB_EE_6);
		sl_contentPane.putConstraint(SpringLayout.WEST, radioB_EE_6, 45, SpringLayout.WEST, lblElementoEstruturante);
		sl_contentPane.putConstraint(SpringLayout.EAST, radioB_EE_6, -6, SpringLayout.WEST, checkMenosX);
		buttonGroup.add(radioB_EE_6);
		radioB_EE_6.setSelected(true);
		radioB_EE_6.addItemListener(handler);
		contentPane.add(radioB_EE_6);
		
		radioB_EE_26 = new JRadioButton("26");
		sl_contentPane.putConstraint(SpringLayout.NORTH, radioB_EE_26, 6, SpringLayout.SOUTH, radioB_EE_18);
		sl_contentPane.putConstraint(SpringLayout.WEST, radioB_EE_26, 0, SpringLayout.WEST, radioB_EE_18);
		sl_contentPane.putConstraint(SpringLayout.EAST, radioB_EE_26, -6, SpringLayout.WEST, checkMenosX);
		radioB_EE_26.addItemListener(handler);
		buttonGroup.add(radioB_EE_26);

		JLabel lblDirees = new JLabel("Directions");
		sl_contentPane.putConstraint(SpringLayout.EAST, radioB_EE_18, -107, SpringLayout.WEST, lblDirees);
		sl_contentPane.putConstraint(SpringLayout.WEST, lblDirees, 209, SpringLayout.WEST, contentPane);
		sl_contentPane.putConstraint(SpringLayout.SOUTH, lblDirees, -17,
				SpringLayout.NORTH, checkMenosY);
		sl_contentPane.putConstraint(SpringLayout.EAST, lblDirees, -164, SpringLayout.EAST, contentPane);
		contentPane.add(lblDirees);

		JButton btnNewButton_1 = new JButton("Start");
		sl_contentPane.putConstraint(SpringLayout.WEST, btnNewButton_1, 77, SpringLayout.WEST, contentPane);
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.gc();
				if (checkMaisX.isSelected() || checkMenosX.isSelected()
						|| checkMaisY.isSelected() || checkMenosY.isSelected()
						|| checkMaisZ.isSelected() || checkMenosZ.isSelected()) {

					ImagePlus imp = WindowManager.getCurrentImage();
					ImageStatistics s = imp.getStatistics();
					// IJ.log(""+s.histMin);
					// IJ.log(""+s.histMax);
					limiar = Integer.parseInt(textFieldLimiar.getText());
					// IJ.log(""+limiar);
					if (limiar > s.histMax || limiar < s.histMin) {
						JOptionPane.showMessageDialog(null,
								"Invalid Threshold. M�x:" + s.histMax + " M�n:"
										+ s.histMin);
						return;
					}
					// hide();
					setVisible(false);

					EventQueue.invokeLater(new Runnable() {
						public void run() {
							try {
								frame = new Janela_2();
								// frame.setVisible(true);

							} catch (Exception e) {
								e.printStackTrace();
							}
						}
					});

				} else {

					JOptionPane.showMessageDialog(null,
							"Select at least one direction.");
				}
			}
		});
		contentPane.add(btnNewButton_1);

		JButton btnCancelar = new JButton("Cancel");
		sl_contentPane.putConstraint(SpringLayout.SOUTH, btnCancelar, -10, SpringLayout.SOUTH, contentPane);
		sl_contentPane.putConstraint(SpringLayout.NORTH, btnNewButton_1, 0, SpringLayout.NORTH, btnCancelar);
		sl_contentPane.putConstraint(SpringLayout.SOUTH, checkMenosZ, -58,
				SpringLayout.NORTH, btnCancelar);
		btnCancelar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		sl_contentPane.putConstraint(SpringLayout.EAST, btnCancelar, -65,
				SpringLayout.EAST, contentPane);
		contentPane.add(btnCancelar);

		comboBox = new JComboBox();
		sl_contentPane.putConstraint(SpringLayout.NORTH, lblElementoEstruturante, 1, SpringLayout.SOUTH, comboBox);
		sl_contentPane.putConstraint(SpringLayout.SOUTH, comboBox, 36,
				SpringLayout.NORTH, contentPane);
		sl_contentPane.putConstraint(SpringLayout.EAST, comboBox, 189,
				SpringLayout.WEST, contentPane);
		// comboBox.setFont(new Font("Serif", Font.PLAIN, 26));
		pilhas = WindowManager.getIDList();
		if (pilhas == null) {
			JOptionPane.showMessageDialog(null, "No open stack. Aborted .");
			dispose();
			// //this.
			return;
		}
		for (int c : pilhas) {
			// System.out.println(c+"\n");
			String ha = WindowManager.getImage(c).getTitle();
			comboBox.addItem(ha);

		}
		// comboBox.addItemListener(new ControleItemChange()); /N�o �
		// necessario, pois ao chamar o histograma a verifica��o � realizada.
		sl_contentPane.putConstraint(SpringLayout.NORTH, comboBox, 16,
				SpringLayout.NORTH, contentPane);
		sl_contentPane.putConstraint(SpringLayout.WEST, comboBox, 15,
				SpringLayout.WEST, contentPane);
		contentPane.add(comboBox);
		contentPane.add(radioB_EE_26);
		
		JLabel lblRegion = new JLabel("Region");
		sl_contentPane.putConstraint(SpringLayout.NORTH, lblRegion, 15, SpringLayout.SOUTH, lblNewLabel);
		sl_contentPane.putConstraint(SpringLayout.WEST, lblRegion, 0, SpringLayout.WEST, lblNewLabel);
		contentPane.add(lblRegion);
		
		rdbtnPoro = new JRadioButton("Black(0)");
		rdbtnPoro.addItemListener(handlerR);
		rdbtnPoro.setEnabled(true);
		buttonGroup_1.add(rdbtnPoro);
		sl_contentPane.putConstraint(SpringLayout.NORTH, rdbtnPoro, 6, SpringLayout.SOUTH, textFieldLimiar);
		contentPane.add(rdbtnPoro);
		
		rdbtnGro = new JRadioButton("White(255)");
		rdbtnGro.addItemListener(handlerR);
		rdbtnGro.setEnabled(true);
		buttonGroup_1.add(rdbtnGro);
		
		sl_contentPane.putConstraint(SpringLayout.WEST, rdbtnPoro, 10, SpringLayout.EAST, rdbtnGro);
		sl_contentPane.putConstraint(SpringLayout.NORTH, rdbtnGro, 6, SpringLayout.SOUTH, textFieldLimiar);
		sl_contentPane.putConstraint(SpringLayout.WEST, rdbtnGro, 0, SpringLayout.WEST, ButtonHistograma);
		rdbtnGro.setSelected(true);
		contentPane.add(rdbtnGro);
		
		radioB_EE_8 = new JRadioButton("8");
		radioB_EE_8.addItemListener(handler2);
		radioB_EE_8.setEnabled(true);
		buttonGroup_2.add(radioB_EE_8);
		sl_contentPane.putConstraint(SpringLayout.NORTH, radioB_EE_6, 19, SpringLayout.SOUTH, radioB_EE_8);
		sl_contentPane.putConstraint(SpringLayout.WEST, radioB_EE_8, 0, SpringLayout.WEST, radioB_EE_18);
		contentPane.add(radioB_EE_8);
		
		radioB_EE_4 = new JRadioButton("4");
		radioB_EE_4.setSelected(true);
		radioB_EE_4.addItemListener(handler2);
		
		buttonGroup_2.add(radioB_EE_4);
		sl_contentPane.putConstraint(SpringLayout.NORTH, radioB_EE_8, 3, SpringLayout.SOUTH, radioB_EE_4);
		sl_contentPane.putConstraint(SpringLayout.WEST, radioB_EE_4, 0, SpringLayout.WEST, radioB_EE_18);
		sl_contentPane.putConstraint(SpringLayout.SOUTH, radioB_EE_4, 0, SpringLayout.SOUTH, lblRegion);
		contentPane.add(radioB_EE_4);
		
		JRadioButton rdbtnd = new JRadioButton("3D");
		buttonGroup_3.add(rdbtnd);
		rdbtnd.addItemListener(handlerD);
		sl_contentPane.putConstraint(SpringLayout.NORTH, rdbtnd, 0, SpringLayout.NORTH, radioB_EE_18);
		sl_contentPane.putConstraint(SpringLayout.WEST, rdbtnd, 0, SpringLayout.WEST, lblElementoEstruturante);
		contentPane.add(rdbtnd);
		
		JRadioButton rdbtnd_1 = new JRadioButton("2D");
		checkMenosZ.setSelected(false);
		checkMenosZ.setEnabled(false);
		checkMaisZ.setSelected(false);
		checkMaisZ.setEnabled(false);
		radioB_EE_6.setEnabled(false);
		radioB_EE_18.setEnabled(false);
		radioB_EE_26.setEnabled(false);
		
		rdbtnd_1.setSelected(true);
		this.EE=4;
		rdbtnd_1.addItemListener(handlerD);
		buttonGroup_3.add(rdbtnd_1);
		sl_contentPane.putConstraint(SpringLayout.NORTH, rdbtnd_1, 0, SpringLayout.NORTH, lblRegion);
		sl_contentPane.putConstraint(SpringLayout.WEST, rdbtnd_1, 0, SpringLayout.WEST, lblElementoEstruturante);
		contentPane.add(rdbtnd_1);
		setInstance(this);// Nova_Janela.setInstance(this);
		uniqueInstance.setVisible(true);
		new MemoryMonitor();
	}
	
	private class RadioButtonHandler implements ItemListener{

		@Override
		public void itemStateChanged(ItemEvent event) {
			JRadioButton b= (JRadioButton) event.getSource();
			String text=b.getText();
			
			if(text.equals("6"))
				Janela_1.uniqueInstance.EE=6;
			if(text.equals("18"))
				Janela_1.uniqueInstance.EE=18;
			if(text.equals("26"))
				Janela_1.uniqueInstance.EE=26;
		
		
	}
	}
		
		private class RadioButtonHandler2 implements ItemListener{

			@Override
			public void itemStateChanged(ItemEvent event) {
				JRadioButton b= (JRadioButton) event.getSource();
				String text=b.getText();
				
				if(text.equals("4")){
					Janela_1.uniqueInstance.EE=4;
				}else if(text.equals("8")){
					Janela_1.uniqueInstance.EE=4;
					Janela_1.uniqueInstance.radioB_EE_4.setSelected(true);
				}
				
			}
		}
	private class RadioButtonHandlerD implements ItemListener{

		@Override
		public void itemStateChanged(ItemEvent event) {
			JRadioButton b= (JRadioButton) event.getSource();
			String text=b.getText();
			if(text.equals("2D")){
				Janela_1.uniqueInstance.radioB_EE_4.setEnabled(true);
				Janela_1.uniqueInstance.radioB_EE_4.setSelected(true);
				Janela_1.uniqueInstance.EE=4;
				Janela_1.uniqueInstance.radioB_EE_8.setEnabled(true);
				
				Janela_1.uniqueInstance.radioB_EE_6.setEnabled(false);
				Janela_1.uniqueInstance.radioB_EE_18.setEnabled(false);
				Janela_1.uniqueInstance.radioB_EE_26.setEnabled(false);
				
				Janela_1.uniqueInstance.checkMenosZ.setSelected(false);
				Janela_1.uniqueInstance.checkMenosZ.setEnabled(false);
				Janela_1.uniqueInstance.checkMaisZ.setSelected(false);
				Janela_1.uniqueInstance.checkMaisZ.setEnabled(false);
			
		}else{
			
				Janela_1.uniqueInstance.radioB_EE_4.setEnabled(false);
				Janela_1.uniqueInstance.radioB_EE_8.setEnabled(false);
		
				Janela_1.uniqueInstance.radioB_EE_6.setSelected(true);
				Janela_1.uniqueInstance.EE=6;
				Janela_1.uniqueInstance.radioB_EE_6.setEnabled(true);
				Janela_1.uniqueInstance.radioB_EE_18.setEnabled(true);
				Janela_1.uniqueInstance.radioB_EE_26.setEnabled(true);
		
				Janela_1.uniqueInstance.checkMenosZ.setEnabled(true);
				Janela_1.uniqueInstance.checkMaisZ.setEnabled(true);
			
				
		}
	}
		}
	private class RadioR implements ItemListener{
		//DEU ERRO NESSE DAQUI
				@Override
				public void itemStateChanged(ItemEvent event) {
					JRadioButton b= (JRadioButton) event.getSource();
					String text=b.getText();
					
					if(text.equals("White(255)")){
						
						regiao = (byte) 255;
					}else{
						regiao = (byte) 0;			
					}
					
				
				
			}
			}
	class CheckBoxListener implements ItemListener {

		@Override
		public void itemStateChanged(ItemEvent e) {
			// TODO Auto-generated method stub
			JCheckBox chk = (JCheckBox) e.getSource();
			if (chk.isSelected() == true) {
				numDirec++;
			} else {
				numDirec--;
			}

		}
	}
		}
	
