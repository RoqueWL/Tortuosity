package controle;



import janelas.Janela_1;
import janelas.Janela_2;
import ij.IJ;

import ij.ImagePlus;
import ij.ImageStack;
import ij.WindowManager;
import ij.process.ByteProcessor;
import ij.process.FloatProcessor;
import ij.process.ShortProcessor;

import javax.swing.JLabel;
import javax.swing.JProgressBar;


public class Processar extends Thread {

	byte type, regiao;
	int limiar;
	int EE;
	private static final int BYTE = 0, SHORT = 1, FLOAT = 2, RGB = 3;
	int altura, largura;
	JLabel progresso;
	JProgressBar barraGeral;
	Janela_2 ref;
	//Janela_1 refJ1;
	public Processar(JProgressBar barraGeral, JLabel progresso) {

		this.barraGeral = barraGeral;
		this.progresso = progresso;
		this.ref = Janela_2.getInstance();
		//refJ1=Janela_1.getInstance();
	}

	public void run() {

		// String dir1 = IJ.getDirectory("Indique a pasta de origem...");
		// Opener op=new Opener();
		Janela_1 UniqueJanela = Janela_1.getInstance();
		this.EE = UniqueJanela.getEE();
		this.limiar = UniqueJanela.limiar;
		this.regiao = UniqueJanela.regiao;
		// op.openMultiple();
		// System.out.println("Ocupando:"+Runtime.getRuntime().totalMemory()/1000000);
		// System.out.println("Livre:"+Runtime.getRuntime().maxMemory()/1000000);
		//IJ.showMessage("Processando");
		ImagePlus imp = WindowManager.getImage(UniqueJanela.comboBox
				.getSelectedItem().toString());
		if (imp == null) {
			IJ.showMessage("Stack required");
			
			return;
		}
		if(this.EE==4 || this.EE==8){
			if(imp.getStackSize() > 1){
				IJ.showMessage("Invalid image");
				return;
		}
		}else{
			 if(!(imp.getStackSize() > 1)){
				 IJ.showMessage("Stack required");
				 return;
			 }
		}
		int altura = imp.getHeight();
		int largura = imp.getWidth();
		ImageStack imp3 = imp.getImageStack();
		int nImag = imp.getStackSize();

		IJ.log("\nAltura:" + altura);
    	IJ.log("Largura:" + largura);
	    IJ.log("Fatias:" + nImag);
	    IJ.log("EE:"+ EE);
	    IJ.log("Regi�o:"+ (0xFF&regiao) );
		// / GenericDialog gd = new GenericDialog("Especifique os param�tros",
		// IJ.getInstance());
	    
	   // IJ.log("Passei: ");

		byte objetoCompleto[][] = new byte[nImag][altura * largura];
		// ImageProcessor test=imp.getProcessor();
		// test.

		// if (dir1==null) return;

		// ImageProcessor ip=op.stack.getProcessor(cont);
		// int limiar; // apenas 1 caso
		// limiar = 128; // IMPLEMENTAR OUTROS CASOS
		if (imp.getProcessor() instanceof ByteProcessor) {
			for (int cont = 1; cont <= nImag; cont++) {
				type = BYTE;
				//imp3.getProcessor(cont).threshold(limiar);
				objetoCompleto[cont - 1] = (byte[]) imp3.getProcessor(cont).getPixels();
			}

		} else if (imp.getProcessor() instanceof ShortProcessor) {
			type = SHORT;
			IJ.log("Codifica��o n�o suportada: " + type);
			ref.dispose();                                      ///////////////   TESTAR DISPOSE NOS CASOS QUE N�O S�O EM ESCALA DE CINZA
		} else if (imp.getProcessor() instanceof FloatProcessor) {
			type = FLOAT;
			IJ.log("Codifica��o n�o suportada: " + type);
			ref.dispose();
		} else {
			type = RGB;
			IJ.log("Codifica��o n�o suportada: " + type);
			ref.dispose();
		}

		byte imagemRef[][][] = new byte[nImag][altura][largura];
		progresso.setText("Applying threshold");
		if(regiao==(byte)255){
			
		for (int i = 0; i < (altura); i++) {
			for (int j = 0; j < largura; j++) {
				for (int k = 0; k < nImag; k++) {

					if ( (0xFF & objetoCompleto[k][(i * largura)+j]) < limiar)
						imagemRef[k][i][j] = (byte)0;
					else
						imagemRef[k][i][j] = (byte)255;
				}

			}

			barraGeral.setValue(i);
		}
		}else{
			for (int i = 0; i < (altura); i++) {
				for (int j = 0; j < largura; j++) {
					for (int k = 0; k < nImag; k++) {

						if ( (0xFF & objetoCompleto[k][(i * largura)+j]) < limiar)
							imagemRef[k][i][j] = (byte)255;
						else
							imagemRef[k][i][j] = (byte)0;
					}

				}

				barraGeral.setValue(i);
			}
		}
		// System.out.println("Ocupando:"+Runtime.getRuntime().totalMemory()/1000000);
		// System.out.println("Livre:"+Runtime.getRuntime().maxMemory()/1000000);
		//objetoCompleto = null;
		imp = null;
		imp3 = null;
		progresso.setText("Threshold applied");
		barraGeral.setEnabled(false);

		int i = 0;

		this.ref.Threads=new ThreadCalcular[UniqueJanela.numDirec];
		if (UniqueJanela.checkMaisX.isSelected()) {

			ref.pX = new Xmais_teste(largura, altura, nImag, imagemRef, ref.progressBarPx,
					ref.labelPX, ref.tabelaPX, ref.tabbedPane);
			
			
			
			this.ref.Threads[i]=new ThreadCalcular(ref.pX, 1, EE);
			this.ref.Threads[i].start();
			i++;
			// System.out.println("Ocupando:"+Runtime.getRuntime().totalMemory()/1000000);
			// System.out.println("Livre:"+Runtime.getRuntime().maxMemory()/1000000);
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			// EventQueue.invokeLater(new ThreadCalcular(ref.pX, 1));
		}
		if (UniqueJanela.checkMenosX.isSelected()) {

			ref.nX = new Xmenos_teste(largura, altura, nImag, imagemRef, ref.progressBarNx,
					ref.labelNX, ref.tabelaNX, ref.tabbedPane); // Qual o melhor
																// tipo de dado
																// para
																// manipular??
			this.ref.Threads[i]=new ThreadCalcular(ref.nX, 2, EE);
			this.ref.Threads[i].start();
			i++;
			// System.out.println("Ocupando:"+Runtime.getRuntime().totalMemory()/1000000);
			// System.out.println("Livre:"+Runtime.getRuntime().maxMemory()/1000000);
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			// EventQueue.invokeLater(new ThreadCalcular(ref.nX, 2));
		}


	if (UniqueJanela.checkMaisY.isSelected()) {

			ref.pY = new Ymais_teste(largura, altura, nImag, imagemRef, ref.progressBarPy,
					ref.labelPY, ref.tabelaPY, ref.tabbedPane); // Qual o melhor
																// tipo de dado
																// para
																// manipular??
			this.ref.Threads[i]=new ThreadCalcular(ref.pY, 3, EE);
			this.ref.Threads[i].start();
			i++;
			// System.out.println("Ocupando:"+Runtime.getRuntime().totalMemory()/1000000);
			// System.out.println("Livre:"+Runtime.getRuntime().maxMemory()/1000000);
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			// EventQueue.invokeLater(new ThreadCalcular(ref.pY, 3));
		}
		if (UniqueJanela.checkMenosY.isSelected()) {

			ref.nY = new Ymenos_teste(largura, altura, nImag, imagemRef, ref.progressBarNy,
					ref.labelNY, ref.tabelaNY, ref.tabbedPane); // Qual o melhor
																// tipo de dado
																// para
																// manipular??
			this.ref.Threads[i]=new ThreadCalcular(ref.nY, 4, EE);
			this.ref.Threads[i].start();
			i++;
			// System.out.println("Ocupando:"+Runtime.getRuntime().totalMemory()/1000000);
			// System.out.println("Livre:"+Runtime.getRuntime().maxMemory()/1000000);
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			// EventQueue.invokeLater(new ThreadCalcular(ref.nZ, 6));
		}
		if (UniqueJanela.checkMaisZ.isSelected()) {

			ref.pZ = new Zmais_teste(largura, altura, nImag, imagemRef, ref.progressBarPz,
					ref.labelPZ, ref.tabelaPZ, ref.tabbedPane); // Qual o melhor
																// tipo de dado
																// para
																// manipular??
			this.ref.Threads[i]=new ThreadCalcular(ref.pZ, 5, EE);
			this.ref.Threads[i].start();
			i++;
			// System.out.println("Ocupando:"+Runtime.getRuntime().totalMemory()/1000000);
			// System.out.println("Livre:"+Runtime.getRuntime().maxMemory()/1000000);
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			// EventQueue.invokeLater(new ThreadCalcular(ref.nZ, 6));
		}
		if (UniqueJanela.checkMenosZ.isSelected()) {

			ref.nZ = new Zmenos_teste(largura, altura, nImag,imagemRef, ref.progressBarNz,
					ref.labelNZ, ref.tabelaNZ, ref.tabbedPane); // Qual o melhor
																// tipo de dado
																// para
																// manipular??
			this.ref.Threads[i]=new ThreadCalcular(ref.nZ, 6, EE);
			this.ref.Threads[i].start();
			i++;
			// System.out.println("Ocupando:"+Runtime.getRuntime().totalMemory()/1000000);
			// System.out.println("Livre:"+Runtime.getRuntime().maxMemory()/1000000);
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			// EventQueue.invokeLater(new ThreadCalcular(ref.nZ, 6));
		}
		// new ControladorTabelaGeral(threads).start();
		ref.imagens = new Imagem[i];
		i = 0;

		if (UniqueJanela.checkMaisX.isSelected()) {
			ref.imagens[i] = ref.pX;
			i++;
			// EventQueue.invokeLater(new ThreadCalcular(ref.pX, 1));
		}

		if (UniqueJanela.checkMenosX.isSelected()) {
			ref.imagens[i] = ref.nX;
			i++;
			// EventQueue.invokeLater(new ThreadCalcular(ref.nX, 2));
		}

		if (UniqueJanela.checkMaisY.isSelected()) {
			ref.imagens[i] = ref.pY;
			i++;
			// EventQueue.invokeLater(new ThreadCalcular(ref.pY, 3));
		}
		if (UniqueJanela.checkMenosY.isSelected()) {
			ref.imagens[i] = ref.nY;
			i++;
			// EventQueue.invokeLater(new ThreadCalcular(ref.nZ, 6));
		}
		if (UniqueJanela.checkMaisZ.isSelected()) {
			ref.imagens[i] = ref.pZ;
			i++;
			// EventQueue.invokeLater(new ThreadCalcular(ref.nZ, 6));
		}
		if (UniqueJanela.checkMenosZ.isSelected()) {
			ref.imagens[i] = ref.nZ;
			i++;
			// EventQueue.invokeLater(new ThreadCalcular(ref.nZ, 6));
		}

	}

}
