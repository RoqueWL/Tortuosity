package controle;

import javax.swing.table.AbstractTableModel;

public class TabelaAbas extends AbstractTableModel {

	Imagem im;
	
	public TabelaAbas(Imagem im){
		
		this.im=im;
	}
	@Override
	public String getColumnName(int column) {
		   switch (column) {
		   case 0:
		     return "T";
		   case 1:
		     return "Tortuosity";
		   }
		   return "";
		 }
	
	public int getRowCount() {
		// TODO Auto-generated method stub
		return 2;
	}

	@Override
	public int getColumnCount() {
		// TODO Auto-generated method stub
		return 2;
	}

	@Override
	public Object getValueAt(int linha, int coluna) {
		    // Negocio negocio = lista.get(linha);
		
		     switch(coluna) {
		     case 0:
		    	 if(linha==0){
		    		 return "T (Distribution)";	 
		    	 }else{
		    		 return "T (Mean)";
		    	 }
		       
		     case 1:
		    	 if(linha==0){
		    		return im.a1.doubleValue();
		    	 }else{
		    		 return im.A1.doubleValue(); /// A1	 
		    	 }
		      
		     }
		     return "";
		   }
	
	}
