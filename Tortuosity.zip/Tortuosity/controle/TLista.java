package controle;

public class TLista {

	public TNo cabeca;
	private int tamanho;

	public TLista() {
		this.cabeca = null;
		this.tamanho = 0;
	}


	public static boolean vazia(TLista lista) {
		if (lista.tamanho == 0)
			return true;
		else
			return false;

	}

	public int tamanho() {
		return this.tamanho;
	}


	

	public static int insereListaVazia(TLista lista, int i, int j, int k) {
		lista.cabeca = new TNo(i, j, k);
		lista.tamanho++;
		return 1;
	}

	
	public void insere(int i,int j, int k){
		
		this.cabeca = new TNo(this.cabeca, i, j, k);
		this.tamanho++;
		
	}

public void insere(TNo no){
		
		this.cabeca = new TNo(this.cabeca, no);
		this.tamanho++;
		
	}
	
	
	public void retira() {
		this.cabeca=this.cabeca.proximo;
		this.tamanho--;
	}
	
	public void retira(TLista lista2) {
		lista2.insere(this.cabeca);
		this.cabeca=this.cabeca.proximo;
		this.tamanho--;
	}
	
	
}
