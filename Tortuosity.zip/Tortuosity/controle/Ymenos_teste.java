/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controle;


import ij.IJ;

import java.math.BigDecimal;
import java.math.RoundingMode;

import javax.swing.JLabel;
import javax.swing.JProgressBar;
import javax.swing.JTabbedPane;
import javax.swing.JTable;











import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

/**
 * 
 * @author UFPB-CIA-03
 */
public class Ymenos_teste extends Imagem {
	// boolean imagemRec3d[][][];
	// int aux_med[];
	 boolean teste;
	public Ymenos_teste(int w, int h, int nImag, byte[][][] im, JProgressBar bar,
			JLabel progresso, JTable tabela, JTabbedPane tabbedPane) {
		super("(-Y)", w, h, nImag, im, bar, progresso, tabela, tabbedPane);

	}
	public boolean reconstr(int EE, ThreadCalcular thread) {
		this.EE=EE;
		grafico=false;
imagemRec3d = new boolean[altura][largura][imagemRef.length];

retaMelhorAjusteDis = new XYSeries("Best Fit Line", false);
tortuosidadeMed = new XYSeries("Mean <Le,Lg>", false);
retaMelhorAjusteMed = new XYSeries("Best Fit Line", false);
pontosReconstruidos = new XYSeries("Distribution", false);

		
		this.lista2 = new TLista();
		this.lista = new TLista();
		for (int k = 0; k < imagemRef.length; k++) {
			for (int j = 0; j < largura; j++) {
				if( imagemRef[k][altura - 1][j] == (byte) 255){
					imagemRec3d[altura - 1][j][k] =true;
					lista2.insere(altura - 1, j, k);
				}
				
			}
		}
		
		progresso.setText("Reconstructing -Y");
		bar.setIndeterminate(true);
		
		
		medias = new BigDecimal[altura];
		aux_med=new BigDecimal[altura];
		for(int i=0;i<altura;i++){
		medias[i]=new BigDecimal("0.0");
		aux_med[i]=new BigDecimal("0.0");
		}
		d = 0;
		while (t&&!Thread.currentThread().isInterrupted()) {
			bar.setString("Rec: " + d);
			dilata(EE, d);
			d+=2;
		}
		if(t){
			return true;
		}
		d--;
		//bar.setString("Rec: " + d);
		bar.setIndeterminate(false);
		progresso.setText(" -Y ");
		/*	IJ.log("soma XY"+somaXY.intValue());
		IJ.log("soma Y"+somaY.intValue());
		IJ.log("somaXquadr"+somaXquadr.intValue());
		IJ.log("Qtd pontos: "+m.intValue());
		*/
		int res = (m.compareTo(new BigDecimal("0.0")));
		if (res == 0) {
			a1 = new BigDecimal("0.0");
			a0 = new BigDecimal("0.0");
			return true;
		}
		a1 = (somaXY.subtract((somaX.multiply(somaY)).divide(m, 9,
				RoundingMode.HALF_UP))).divide(somaXquadr.subtract((somaX
				.pow(2)).divide(m, 9, RoundingMode.HALF_UP)), 9,
				RoundingMode.HALF_UP);
		a0 = (somaY.divide(m, 9, RoundingMode.HALF_UP)).subtract(a1
				.multiply(somaX.divide(m, 9, RoundingMode.HALF_UP)));
		m = new BigDecimal(Integer.toString(medias.length));
		Yb = new BigDecimal("0.0");
		Xb = new BigDecimal("0.0");
		somaX = new BigDecimal("0.0");
		somaXquadr = new BigDecimal("0.0");
		somaY = new BigDecimal("0.0");
		somaXY = new BigDecimal("0.0");
		for (int i = 1; i < medias.length; i++) {
			if (0 == medias[i].compareTo(new BigDecimal("0.0"))) {
				break;
			}
			
			medias[i] = medias[i].divide(aux_med[i], 9, RoundingMode.HALF_UP);
			
			
					tortuosidadeMed.add(i, medias[i].floatValue());

			somaX = somaX.add(new BigDecimal(Integer.toString(i)));

			somaXquadr = somaXquadr.add(new BigDecimal(Integer.toString(i))
					.pow(2));
			somaY = somaY.add(medias[i]);
			somaXY = somaXY.add(new BigDecimal(Integer.toString(i))
					.multiply(medias[i]));

			// m = m.add(new BigDecimal("1.0"));

		}

		res = (m.compareTo(new BigDecimal("0.0")));
		if (res == 0) {
			A1 = new BigDecimal("0.0");
			A0 = new BigDecimal("0.0");
			return true;
		}
		A1 = (somaXY.subtract((somaX.multiply(somaY)).divide(m, 9,
				RoundingMode.HALF_UP))).divide(somaXquadr.subtract((somaX
				.pow(2)).divide(m, 9, RoundingMode.HALF_UP)), 9,
				RoundingMode.HALF_UP);
		A0 = (somaY.divide(m, 9, RoundingMode.HALF_UP)).subtract(A1
				.multiply(somaX.divide(m, 9, RoundingMode.HALF_UP)));

		retaMelhorAjusteDis.add(0.0, a0.floatValue());
		retaMelhorAjusteDis.add(altura, a0.floatValue() + a1.floatValue()
				* altura);
		retaMelhorAjusteMed.add(.0f, A0.floatValue());
		retaMelhorAjusteMed.add(altura, A0.floatValue() + A1.floatValue()
				* altura);
return false;

	}
	public void consulta(int i, int j, int k, int RECONSTRUCAO){
		try {
			if(imagemRef[k][(i)][j] == (byte)255 && imagemRec3d[i][j][k] == false){
				
			if(grafico){
				imagemRec3d[(i)][j][k]=true;
				pontosReconstruidos.add(altura - 1 -i, RECONSTRUCAO);
				lista2.insere(i, j, k);
				teste=false;
				return;
			}
				imagemRec3d[(i)][j][k]=true;
				
				aux_med[altura - 1 - i]=aux_med[altura - 1 - i].add(new BigDecimal("1.0"));
				
				this.medias[altura - 1 - i]=this.medias[altura - 1 - i].add(new BigDecimal(RECONSTRUCAO));
				somaX = somaX.add(new BigDecimal(Integer.toString(altura - 1 - i)));
				lista2.insere(i, j, k);
				somaXquadr = somaXquadr.add(new BigDecimal(Integer
						.toString(altura - 1 - i)).pow(2));
				somaY = somaY.add(new BigDecimal(Integer
						.toString(RECONSTRUCAO)));
				somaXY = somaXY
						.add(new BigDecimal(Integer.toString(altura - 1 - i)).multiply((new BigDecimal(
								Integer.toString(RECONSTRUCAO)))));

				m = m.add(new BigDecimal("1.0"));
				teste=false;
			}
		} catch (ArrayIndexOutOfBoundsException ex) {
		}
		
	}
	public void consulta2(int i, int j, int k, int RECONSTRUCAO){
		try {
			if(imagemRef[k][(i)][j] == (byte)255 && imagemRec3d[i][j][k] == false){
				if(grafico){
					imagemRec3d[(i)][j][k]=true;
					pontosReconstruidos.add(altura - 1 -i, RECONSTRUCAO);
					lista.insere(i, j, k);
					teste=false;
					return;
				}
				
				aux_med[altura - 1 - i]=aux_med[altura - 1 - i].add(new BigDecimal("1.0"));
				imagemRec3d[(i)][j][k]=true;
				
				this.medias[altura - 1 - i]=this.medias[altura - 1 - i].add(new BigDecimal(RECONSTRUCAO));
				somaX = somaX.add(new BigDecimal(Integer.toString(altura-1-i)));
				lista.insere(i, j, k);
				somaXquadr = somaXquadr.add(new BigDecimal(Integer
						.toString(altura - 1 - i)).pow(2));
				somaY = somaY.add(new BigDecimal(Integer
						.toString(RECONSTRUCAO)));
				somaXY = somaXY
						.add(new BigDecimal(Integer.toString(altura - 1 - i)).multiply((new BigDecimal(
								Integer.toString(RECONSTRUCAO)))));

				m = m.add(new BigDecimal("1.0"));
				teste=false;
			}
		} catch (ArrayIndexOutOfBoundsException ex) {
		}
		
}
	public void dilata(int EE, int RECONSTRUCAO) {
		 teste = true;
		
		if (EE == 4) {
			
				int i, j, k=0;
				while (lista.cabeca != null) {

					i = lista.cabeca.getI();
					j = lista.cabeca.getJ();
					
					for (int aux = -1; aux < 2; aux += 2) {
					
					consulta(i+aux,j,k,RECONSTRUCAO);
					consulta(i,j+aux,k,RECONSTRUCAO);
					
					}
					lista.retira();

				}
			 
			
			
			
				if(lista2.cabeca != null){
					RECONSTRUCAO++;	
				}
				
				while (lista2.cabeca != null) {
					
					i = lista2.cabeca.getI();
					j = lista2.cabeca.getJ();
					
					for (int aux = -1; aux < 2; aux += 2) {
						

						consulta2(i+aux,j,k,RECONSTRUCAO);
						consulta2(i,j+aux,k,RECONSTRUCAO);
						
					
						
					}
					lista2.retira();
					
				}
			
				
			if (teste) {
				this.d--;
				this.t = false;
			}
			
		}else if (EE == 6) {
			
				int i, j, k;
				while (lista.cabeca != null) {

					i = lista.cabeca.getI();
					j = lista.cabeca.getJ();
					k = lista.cabeca.getK();
					for (int aux = -1; aux < 2; aux += 2) {
						consulta(i+aux,j,k,RECONSTRUCAO);
						consulta(i,j+aux,k,RECONSTRUCAO);
						consulta(i,j,k+aux,RECONSTRUCAO);
						
					}
					lista.retira();

				}
		
			if(lista2.cabeca != null){
				RECONSTRUCAO++;	
			//	System.out.println("lista2 != null");
			}
			//	int i, j, k;
				while (lista2.cabeca != null) {

					i = lista2.cabeca.getI();
					j = lista2.cabeca.getJ();
					k = lista2.cabeca.getK();
				//	IJ.log("entrei3");
					for (int aux = -1; aux < 2; aux += 2) {
						
						consulta2(i+aux,j,k,RECONSTRUCAO);
						consulta2(i,j+aux,k,RECONSTRUCAO);
						consulta2(i,j,k+aux,RECONSTRUCAO);
					
					}
					lista2.retira();
				}
			

			if (teste) {
				this.d--;
				this.t = false;
			}
			
		} else if (EE == 18) {
			
			
				int i, j, k;
				while (lista.cabeca != null) {

					i = lista.cabeca.getI();
					j = lista.cabeca.getJ();
					k = lista.cabeca.getK();
					for (int aux = -1; aux < 2; aux += 2) {
						consulta(i+aux,j,k,RECONSTRUCAO);
						consulta(i,j+aux,k,RECONSTRUCAO);
						consulta(i,j,k+aux,RECONSTRUCAO);
						consulta(i+aux,j+aux,k,RECONSTRUCAO);
						consulta(i+aux,j-aux,k,RECONSTRUCAO);
						consulta(i,j+aux,k+aux,RECONSTRUCAO);
						consulta(i,j+aux,k-aux,RECONSTRUCAO);
						consulta(i+aux,j,k+aux,RECONSTRUCAO);
						consulta(i+aux,j,k-aux,RECONSTRUCAO);
						
					}
					lista.retira();

				}
		
			
			
			
			while (lista2.cabeca != null) {

				i = lista2.cabeca.getI();
				j = lista2.cabeca.getJ();
				k = lista2.cabeca.getK();
				for (int aux = -1; aux < 2; aux += 2) {
					consulta2(i+aux,j,k,RECONSTRUCAO);
					consulta2(i,j+aux,k,RECONSTRUCAO);
					consulta2(i,j,k+aux,RECONSTRUCAO);
					consulta2(i+aux,j+aux,k,RECONSTRUCAO);
					consulta2(i+aux,j-aux,k,RECONSTRUCAO);
					consulta2(i,j+aux,k+aux,RECONSTRUCAO);
					consulta2(i,j+aux,k-aux,RECONSTRUCAO);
					consulta2(i+aux,j,k+aux,RECONSTRUCAO);
					consulta2(i+aux,j,k-aux,RECONSTRUCAO);
				}
					lista2.retira();
				}
			
		

		if (teste) {
			this.t = false;
		}
			

		}else if(EE==26){
			
			
				int i, j, k;
				while (lista.cabeca != null) {

					i = lista.cabeca.getI();
					j = lista.cabeca.getJ();
					k = lista.cabeca.getK();
					for (int aux = -1; aux < 2; aux += 2) {
						consulta(i+aux,j,k,RECONSTRUCAO);
						consulta(i,j+aux,k,RECONSTRUCAO);
						consulta(i,j,k+aux,RECONSTRUCAO);
						consulta(i+aux,j+aux,k,RECONSTRUCAO);
						consulta(i+aux,j-aux,k,RECONSTRUCAO);
						consulta(i,j+aux,k+aux,RECONSTRUCAO);
						consulta(i,j+aux,k-aux,RECONSTRUCAO);
						consulta(i+aux,j,k+aux,RECONSTRUCAO);
						consulta(i+aux,j,k-aux,RECONSTRUCAO);
						consulta(i+aux,j+aux,k+aux,RECONSTRUCAO);
						consulta(i-aux,j+aux,k+aux,RECONSTRUCAO);
						consulta(i+aux,j-aux,k+aux,RECONSTRUCAO);
						consulta(i+aux,j+aux,k-aux,RECONSTRUCAO);
						
					}
					lista.retira();

				}
			
			
			
			while (lista2.cabeca != null) {

				i = lista2.cabeca.getI();
				j = lista2.cabeca.getJ();
				k = lista2.cabeca.getK();
				for (int aux = -1; aux < 2; aux += 2) {
					consulta2(i+aux,j,k,RECONSTRUCAO);
					consulta2(i,j+aux,k,RECONSTRUCAO);
					consulta2(i,j,k+aux,RECONSTRUCAO);
					consulta2(i+aux,j+aux,k,RECONSTRUCAO);
					consulta2(i+aux,j-aux,k,RECONSTRUCAO);
					consulta2(i,j+aux,k+aux,RECONSTRUCAO);
					consulta2(i,j+aux,k-aux,RECONSTRUCAO);
					consulta2(i+aux,j,k+aux,RECONSTRUCAO);
					consulta2(i+aux,j,k-aux,RECONSTRUCAO);
					consulta2(i+aux,j+aux,k+aux,RECONSTRUCAO);
					consulta2(i-aux,j+aux,k+aux,RECONSTRUCAO);
					consulta2(i+aux,j-aux,k+aux,RECONSTRUCAO);
					consulta2(i+aux,j+aux,k-aux,RECONSTRUCAO);
					
				}
				lista2.retira();
			}
		

		if (teste) {
			this.t = false;
		}
		
		}
		
	}

	public void calcularTortuosidade() {

		// int i;//, p;
		medias = new BigDecimal[altura];
		bar.setMaximum(altura);
		// int j;//, p;
	/*	for (int i = 0; i < altura; i++) {
			BigDecimal aux = new BigDecimal("0.0");
			medias[i] = new BigDecimal("0.0");
			for (int k = 0; k < imagemRec3d[0].length; k++) {
				for (int j = 0; j < largura; j++) {
					if (imagemRec3d[(i * largura) + j][k] > 0) {
						aux = aux.add(new BigDecimal("1.0"));
						medias[i] = medias[i].add(new BigDecimal(
								imagemRec3d[(i * largura) + j][k]));
						somaX = somaX.add(new BigDecimal(Integer.toString(i)));

						somaXquadr = somaXquadr.add(new BigDecimal(Integer
								.toString(i)).pow(2));
						somaY = somaY.add(new BigDecimal(Integer
								.toString(imagemRec3d[(i * largura) + j][k])));
						somaXY = somaXY
								.add(new BigDecimal(Integer.toString(i)).multiply((new BigDecimal(
										Integer.toString(imagemRec3d[(i * largura)
												+ j][k])))));

						m = m.add(new BigDecimal("1.0"));
					}
				}
			}
			if (0 != aux.compareTo(new BigDecimal("0.0"))) {
				medias[i] = medias[i].divide(aux, 9, RoundingMode.HALF_UP);
			}
			bar.setValue(i + 1);
		}
		int res = (m.compareTo(new BigDecimal("0.0")));
		if (res == 0) {
			a1 = new BigDecimal("0.0");
			a0 = new BigDecimal("0.0");
			return;
		}
		a1 = (somaXY.subtract((somaX.multiply(somaY)).divide(m, 9,
				RoundingMode.HALF_UP))).divide(somaXquadr.subtract((somaX
				.pow(2)).divide(m, 9, RoundingMode.HALF_UP)), 9,
				RoundingMode.HALF_UP);
		a0 = (somaY.divide(m, 9, RoundingMode.HALF_UP)).subtract(a1
				.multiply(somaX.divide(m, 9, RoundingMode.HALF_UP)));
		// /
		// IJ.log("tortuosidade " +orientacao+": EE "+EE+" - "+d+"\n"+
		// a1.toString() +"\n");

		m = new BigDecimal(Integer.toString(medias.length));
		Yb = new BigDecimal("0.0");
		Xb = new BigDecimal("0.0");
		somaX = new BigDecimal("0.0");
		somaXquadr = new BigDecimal("0.0");
		somaY = new BigDecimal("0.0");
		somaXY = new BigDecimal("0.0");
		for (int i = 1; i < medias.length; i++) {
			if (0 == medias[i].compareTo(new BigDecimal("0.0"))) {
				break;
			}
			somaX = somaX.add(new BigDecimal(Integer.toString(i)));

			somaXquadr = somaXquadr.add(new BigDecimal(Integer.toString(i))
					.pow(2));
			somaY = somaY.add(medias[i]);
			somaXY = somaXY.add(new BigDecimal(Integer.toString(i))
					.multiply(medias[i]));

			// m = m.add(new BigDecimal("1.0"));

		}

		res = (m.compareTo(new BigDecimal("0.0")));
		if (res == 0) {
			A1 = new BigDecimal("0.0");
			A0 = new BigDecimal("0.0");
			return;
		}
		A1 = (somaXY.subtract((somaX.multiply(somaY)).divide(m, 9,
				RoundingMode.HALF_UP))).divide(somaXquadr.subtract((somaX
				.pow(2)).divide(m, 9, RoundingMode.HALF_UP)), 9,
				RoundingMode.HALF_UP);
		A0 = (somaY.divide(m, 9, RoundingMode.HALF_UP)).subtract(A1
				.multiply(somaX.divide(m, 9, RoundingMode.HALF_UP)));
		// IJ.log("tortuosidade PELA M�DIA "
		// +orientacao+": EE "+EE+" - "+d+"\n"+ A1.toString() +"\n");
*/
		// showGraph();

	}

	public void preencheGrafico() {
		if(dataset!=null){
			this.showGraph(this.altura);
			return;
		}
		dataset = new XYSeriesCollection();
		dataset2 = new XYSeriesCollection();
		dataset3 = new XYSeriesCollection();
		dataset4 = new XYSeriesCollection();
		dataset.addSeries(pontosReconstruidos);
		dataset2.addSeries(retaMelhorAjusteDis);
		dataset3.addSeries(tortuosidadeMed);
		dataset4.addSeries(retaMelhorAjusteMed);
		this.showGraph(this.altura);
		
		imagemRec3d = new boolean[altura][largura][imagemRef.length];
		
		this.lista2 = new TLista();
		this.lista = new TLista();
		
		for (int k = 0; k < imagemRef.length; k++) {
			for (int j = 0; j < largura; j++) {
				if( imagemRef[k][altura - 1][j] == (byte) 255){
					imagemRec3d[altura - 1][j][k] =true;
					lista2.insere(altura - 1, j, k);
				}
				
			}
		}
		d = 0;
		t=true;
		grafico=true;
		while (t&&!Thread.currentThread().isInterrupted()) {

			dilata(EE, d);
			d+=2;
		}

		
	}

}
