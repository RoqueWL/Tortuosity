package controle;

public class PreencheGrafico extends Thread {
	Imagem imagem;
	public PreencheGrafico(Imagem imagem){
		this.imagem=imagem;
	}

	public void run(){
		
		imagem.preencheGrafico();
		
	}
}
