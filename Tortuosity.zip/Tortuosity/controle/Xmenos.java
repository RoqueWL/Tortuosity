/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controle;


import java.math.BigDecimal;
import java.math.RoundingMode;

import javax.swing.JLabel;
import javax.swing.JProgressBar;
import javax.swing.JTabbedPane;
import javax.swing.JTable;



import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

/**
 * 
 * @author UFPB-CIA-03
 */
public class Xmenos extends Imagem {
	// Plot plot, plot1;

	public Xmenos(int w, int h, int nImag, byte[][][] im, JProgressBar bar,
			JLabel progresso, JTable tabela, JTabbedPane tabbedPane) {

		super("(-X)", w, h, nImag, im, bar, progresso, tabela, tabbedPane);

	}

	public void reconstr(int EE) {

		imagemRec3d = new int[altura * largura][imagemRef.length];
		imagemDil3d = new int[altura][largura][imagemRef.length];

		for (int i = 0; i < altura; i++) {
			for (int k = 0; k < imagemRef.length; k++) {
				imagemRec3d[(i * largura) + largura - 1][k] = imagemRef[k][i][(largura - 1)] == (byte) 255 ? -1
						: -2;

			}
		}
		d = 1;
		progresso.setText("Reconstructing -X");
		bar.setIndeterminate(true);
		this.lista2 = new TLista();
		this.lista = new TLista();
		while (t) {

			dilata(EE, d);
			d++;
		}
		d--;
		bar.setString("Rec: " + d);
		bar.setIndeterminate(false);

		progresso.setText("-X ");

	}

	public void dilata(int EE, int RECONSTRUCAO) {
		boolean teste = true;
		
		if (EE == 4) {
			if (RECONSTRUCAO != 1) {
				int i, j, k;
				while (lista.cabeca != null) {

					i = lista.cabeca.getI();
					j = lista.cabeca.getJ();
					k = 0;
					for (int aux = -1; aux < 2; aux += 2) {
						try {
							imagemDil3d[((i + aux))][j][k] = RECONSTRUCAO;
						} catch (ArrayIndexOutOfBoundsException ex) {
						}
						try {
							imagemDil3d[((i))][j + aux][k] = RECONSTRUCAO;
						} catch (ArrayIndexOutOfBoundsException ex) {
						}
						
						lista2.insere(i, j, 0);
					}
					lista.retira();

				}
			} else {
				for (int j = largura - 1; (j > largura - 1 - RECONSTRUCAO)
						&& (j >= 0); j--) {

					for (int i = 0; i < altura; i++) {

						for (int k = 0; k < nImag; k++) {

							if (imagemRec3d[(i * largura) + j][k] == RECONSTRUCAO - 1
									|| imagemRec3d[(i * largura) + j][k] == -1) {
								if (RECONSTRUCAO == 1
										&& imagemRec3d[(i * largura) + j][k] == 0) { // primeira
																						// exec.
									continue;
								}
								for (int aux = -1; aux < 2; aux += 2) {
									try {
										imagemDil3d[((i + aux))][j][k] = RECONSTRUCAO;
									} catch (ArrayIndexOutOfBoundsException ex) {
									}
									try {
										imagemDil3d[((i))][j + aux][k] = RECONSTRUCAO;
									} catch (ArrayIndexOutOfBoundsException ex) {
									}
									
									lista2.insere(i, j, 0);
								}

							}
						}
					}
				}
			}
			
			
				int i, j, k;
				while (lista2.cabeca != null) {

					i = lista2.cabeca.getI();
					j = lista2.cabeca.getJ();
					k = 0;
					for (int aux = -1; aux < 2; aux += 2) {
						try {
							if (((imagemDil3d[i + aux][j][k] == RECONSTRUCAO)
									&& (imagemRec3d[((i + aux) * largura) + j][k] == 0) && (this.imagemRef[k][i
									+ aux][j] == (byte) 255))) {
								imagemRec3d[((i + aux) * largura) + j][k] = RECONSTRUCAO;
								lista.insere(i + aux, j, k);						
								teste = false;

							}
						} catch (ArrayIndexOutOfBoundsException ex) {

						}
						
						try {
							if (((imagemDil3d[i][j + aux][k] == RECONSTRUCAO)
									&& (imagemRec3d[(i * largura) + j + aux][k] == 0) && (this.imagemRef[k][i][j
									+ aux] == (byte) 255))) {
								imagemRec3d[(i * largura) + j + aux][k] = RECONSTRUCAO;
								lista.insere(i, j + aux, k);						
								teste = false;

							}
						} catch (ArrayIndexOutOfBoundsException ex) {

						}
						lista2.retira();
					}
				}
			

			if (teste) {
				this.t = false;
			}
			
		}else if (EE == 6) {
			if (RECONSTRUCAO != 1) {
				int i, j, k;
				while (lista.cabeca != null) {

					i = lista.cabeca.getI();
					j = lista.cabeca.getJ();
					k = lista.cabeca.getK();
					for (int aux = -1; aux < 2; aux += 2) {
						try {
							imagemDil3d[((i + aux))][j][k] = RECONSTRUCAO;
						} catch (ArrayIndexOutOfBoundsException ex) {
						}
						try {
							imagemDil3d[((i))][j + aux][k] = RECONSTRUCAO;
						} catch (ArrayIndexOutOfBoundsException ex) {
						}
						try {
							imagemDil3d[((i))][j][k + aux] = RECONSTRUCAO;
						} catch (ArrayIndexOutOfBoundsException ex) {
						}
						lista2.insere(i, j, k);
					}
					lista.retira();

				}
			} else {
				for (int j = largura - 1; (j > largura - 1 - RECONSTRUCAO)
						&& (j >= 0); j--) {

					for (int i = 0; i < altura; i++) {

						for (int k = 0; k < nImag; k++) {

							if (imagemRec3d[(i * largura) + j][k] == RECONSTRUCAO - 1
									|| imagemRec3d[(i * largura) + j][k] == -1) {
								if (RECONSTRUCAO == 1
										&& imagemRec3d[(i * largura) + j][k] == 0) { // primeira
																						// exec.
									continue;
								}
								for (int aux = -1; aux < 2; aux += 2) {
									try {
										imagemDil3d[((i + aux))][j][k] = RECONSTRUCAO;
									} catch (ArrayIndexOutOfBoundsException ex) {
										if(i!=altura){
											
										}
									}
									try {
										imagemDil3d[((i))][j + aux][k] = RECONSTRUCAO;
									} catch (ArrayIndexOutOfBoundsException ex) {
									}
									try {
										imagemDil3d[((i))][j][k + aux] = RECONSTRUCAO;
									} catch (ArrayIndexOutOfBoundsException ex) {
									}
									lista2.insere(i, j, k);
								}

							}
						}
					}
				}
			}
			
			
				int i, j, k;
				while (lista2.cabeca != null) {

					i = lista2.cabeca.getI();
					j = lista2.cabeca.getJ();
					k = lista2.cabeca.getK();
					for (int aux = -1; aux < 2; aux += 2) {
						try {
							if (((imagemDil3d[i + aux][j][k] == RECONSTRUCAO)
									&& (imagemRec3d[((i + aux) * largura) + j][k] == 0) && (this.imagemRef[k][i
									+ aux][j] == (byte) 255))) {
								imagemRec3d[((i + aux) * largura) + j][k] = RECONSTRUCAO;
								lista.insere(i + aux, j, k);						
								teste = false;

							}
						} catch (ArrayIndexOutOfBoundsException ex) {

						}
						try {
							if (((imagemDil3d[i][j][k + aux] == RECONSTRUCAO)
									&& (imagemRec3d[(i * largura) + j][k + aux] == 0) && (this.imagemRef[k+aux][i][j] == (byte) 255))) {
								imagemRec3d[(i * largura) + j][k + aux] = RECONSTRUCAO;
								lista.insere(i, j, k + aux);
								teste = false;

							}
						} catch (ArrayIndexOutOfBoundsException ex) {

						}
						try {
							if (((imagemDil3d[i][j + aux][k] == RECONSTRUCAO)
									&& (imagemRec3d[(i * largura) + j + aux][k] == 0) && (this.imagemRef[k][i][j
									+ aux] == (byte) 255))) {
								imagemRec3d[(i * largura) + j + aux][k] = RECONSTRUCAO;
								lista.insere(i, j + aux, k);						
								teste = false;

							}
						} catch (ArrayIndexOutOfBoundsException ex) {

						}
						lista2.retira();
					}
				}
			

			if (teste) {
				this.t = false;
			}
			
		} else if (EE == 18) {
			
			if (RECONSTRUCAO != 1) {
				int i, j, k;
				while (lista.cabeca != null) {

					i = lista.cabeca.getI();
					j = lista.cabeca.getJ();
					k = lista.cabeca.getK();
					for (int aux = -1; aux < 2; aux += 2) {
						try {
							imagemDil3d[((i + aux))][j][k] = RECONSTRUCAO;
						} catch (ArrayIndexOutOfBoundsException ex) {
						}
						try {
							imagemDil3d[((i))][j + aux][k] = RECONSTRUCAO;
						} catch (ArrayIndexOutOfBoundsException ex) {
						}
						try {
							imagemDil3d[((i))][j][k + aux] = RECONSTRUCAO;
						} catch (ArrayIndexOutOfBoundsException ex) {
						}
						try {
							imagemDil3d[((i + aux))][j+aux][k] = RECONSTRUCAO;
						} catch (ArrayIndexOutOfBoundsException ex) {
						}
						try {
							imagemDil3d[((i + aux))][j - aux][k] = RECONSTRUCAO;
						} catch (ArrayIndexOutOfBoundsException ex) {
						}
						try {
							imagemDil3d[i][j+aux][k+aux] = RECONSTRUCAO;
						} catch (ArrayIndexOutOfBoundsException ex) {
						}
						try {
							imagemDil3d[i][j+aux][k-aux] = RECONSTRUCAO;
						} catch (ArrayIndexOutOfBoundsException ex) {
						}
						try {
							imagemDil3d[i+aux][j][k+aux] = RECONSTRUCAO;
						} catch (ArrayIndexOutOfBoundsException ex) {
						}
						try {
							imagemDil3d[i+aux][j][k-aux] = RECONSTRUCAO;
						} catch (ArrayIndexOutOfBoundsException ex) {
						}
						lista2.insere(i, j, k);
					}
					lista.retira();

				}
			} else {
				for (int j = largura - 1; (j > largura - 1 - RECONSTRUCAO)
						&& (j >= 0); j--) {

					for (int i = 0; i < altura; i++) {

						for (int k = 0; k < nImag; k++) {

							if (imagemRec3d[(i * largura) + j][k] == RECONSTRUCAO - 1
									|| imagemRec3d[(i * largura) + j][k] == -1) {
								if (RECONSTRUCAO == 1
										&& imagemRec3d[(i * largura) + j][k] == 0) { // primeira
																						// exec.
									continue;
								}
								for (int aux = -1; aux < 2; aux += 2) {
									try {
										imagemDil3d[((i + aux))][j][k] = RECONSTRUCAO;
									} catch (ArrayIndexOutOfBoundsException ex) {
									}
									try {
										imagemDil3d[((i))][j + aux][k] = RECONSTRUCAO;
									} catch (ArrayIndexOutOfBoundsException ex) {
									}
									try {
										imagemDil3d[((i))][j][k + aux] = RECONSTRUCAO;
									} catch (ArrayIndexOutOfBoundsException ex) {
									}
									try {
										imagemDil3d[((i + aux))][j+aux][k] = RECONSTRUCAO;
									} catch (ArrayIndexOutOfBoundsException ex) {
									}
									try {
										imagemDil3d[((i + aux))][j - aux][k] = RECONSTRUCAO;
									} catch (ArrayIndexOutOfBoundsException ex) {
									}
									try {
										imagemDil3d[i][j+aux][k+aux] = RECONSTRUCAO;
									} catch (ArrayIndexOutOfBoundsException ex) {
									}
									try {
										imagemDil3d[i][j+aux][k-aux] = RECONSTRUCAO;
									} catch (ArrayIndexOutOfBoundsException ex) {
									}
									try {
										imagemDil3d[i+aux][j][k+aux] = RECONSTRUCAO;
									} catch (ArrayIndexOutOfBoundsException ex) {
									}
									try {
										imagemDil3d[i+aux][j][k-aux] = RECONSTRUCAO;
									} catch (ArrayIndexOutOfBoundsException ex) {
									}
									lista2.insere(i, j, k);
								}

							}
						}
					}
				}
			}
			
			int i, j, k;
			while (lista2.cabeca != null) {

				i = lista2.cabeca.getI();
				j = lista2.cabeca.getJ();
				k = lista2.cabeca.getK();
				for (int aux = -1; aux < 2; aux += 2) {
					try {
						if (((imagemDil3d[i + aux][j][k] == RECONSTRUCAO)
								&& (imagemRec3d[((i + aux) * largura) + j][k] == 0) && (this.imagemRef[k][i
								+ aux][j] == (byte) 255))) {
							imagemRec3d[((i + aux) * largura) + j][k] = RECONSTRUCAO;
							lista.insere(i + aux, j, k);						
							teste = false;

						}
					} catch (ArrayIndexOutOfBoundsException ex) {

					}
					try {
						if (((imagemDil3d[i][j + aux][k] == RECONSTRUCAO)
								&& (imagemRec3d[(i * largura) + j + aux][k] == 0) && (this.imagemRef[k][i][j
								+ aux] == (byte) 255))) {
							imagemRec3d[(i * largura) + j + aux][k] = RECONSTRUCAO;
							lista.insere(i, j + aux, k);						
							teste = false;

						}
					} catch (ArrayIndexOutOfBoundsException ex) {

					}
					try {
						if (((imagemDil3d[i][j][k + aux] == RECONSTRUCAO)
								&& (imagemRec3d[(i * largura) + j][k + aux] == 0) && (this.imagemRef[k+aux][i][j] == (byte) 255))) {
							imagemRec3d[(i * largura) + j][k + aux] = RECONSTRUCAO;
							lista.insere(i, j, k + aux);
							teste = false;

						}
					} catch (ArrayIndexOutOfBoundsException ex) {

					}
					
					try {
						if (((imagemDil3d[i+aux][j + aux][k] == RECONSTRUCAO)
								&& (imagemRec3d[((i+aux) * largura) + j + aux][k] == 0) && (this.imagemRef[k][(i+aux)][j
								+ aux] == (byte) 255))) {
							imagemRec3d[((i+aux) * largura) + j + aux][k] = RECONSTRUCAO;
							lista.insere((i+aux), j + aux, k);						
							teste = false;

						}
					} catch (ArrayIndexOutOfBoundsException ex) {

					}
					try {
						if (((imagemDil3d[i+aux][j - aux][k] == RECONSTRUCAO)
								&& (imagemRec3d[((i+aux) * largura) + j - aux][k] == 0) && (this.imagemRef[k][(i - aux)][j
								+ aux] == (byte) 255))) {
							imagemRec3d[((i+aux) * largura) + j - aux][k] = RECONSTRUCAO;
							lista.insere((i+aux), j - aux, k);						
							teste = false;

						}
						} catch (ArrayIndexOutOfBoundsException ex) {

					}
					try {
						if (((imagemDil3d[i][j + aux][(k+aux)] == RECONSTRUCAO)
								&& (imagemRec3d[(i * largura) + j + aux][(k+aux)] == 0) && (this.imagemRef[(k+aux)][i][j
								+ aux] == (byte) 255))) {
							imagemRec3d[(i * largura) + j + aux][(k+aux)] = RECONSTRUCAO;
							lista.insere(i, j + aux, (k+aux));						
							teste = false;

						}
					} catch (ArrayIndexOutOfBoundsException ex) {

					}
					try {
						if (((imagemDil3d[i][j + aux][(k-aux)] == RECONSTRUCAO)
								&& (imagemRec3d[(i * largura) + j + aux][(k-aux)] == 0) && (this.imagemRef[(k-aux)][i][j
								+ aux] == (byte) 255))) {
							imagemRec3d[(i * largura) + j + aux][(k-aux)] = RECONSTRUCAO;
							lista.insere(i, j + aux, (k-aux));						
							teste = false;

						}
					} catch (ArrayIndexOutOfBoundsException ex) {

					}
					try {
						if (((imagemDil3d[i + aux][j][(k+aux)] == RECONSTRUCAO)
								&& (imagemRec3d[((i + aux) * largura) + j][(k+aux)] == 0) && (this.imagemRef[(k+aux)][i
								+ aux][j] == (byte) 255))) {
							imagemRec3d[((i + aux) * largura) + j][(k+aux)] = RECONSTRUCAO;
							lista.insere(i + aux, j, (k+aux));						
							teste = false;

						}
					} catch (ArrayIndexOutOfBoundsException ex) {

					}
					try {
						if (((imagemDil3d[i + aux][j][(k-aux)] == RECONSTRUCAO)
								&& (imagemRec3d[((i + aux) * largura) + j][(k-aux)] == 0) && (this.imagemRef[(k-aux)][i
								+ aux][j] == (byte) 255))) {
							imagemRec3d[((i + aux) * largura) + j][(k-aux)] = RECONSTRUCAO;
							lista.insere(i + aux, j, (k-aux));						
							teste = false;

						}
					} catch (ArrayIndexOutOfBoundsException ex) {

					}
					lista2.retira();
				}
			}
		

		if (teste) {
			this.t = false;
		}
			

		}else if(EE==26){
			
			if (RECONSTRUCAO != 1) {
				int i, j, k;
				while (lista.cabeca != null) {

					i = lista.cabeca.getI();
					j = lista.cabeca.getJ();
					k = lista.cabeca.getK();
					for (int aux = -1; aux < 2; aux += 2) {
						try {
							imagemDil3d[((i + aux))][j][k] = RECONSTRUCAO;
						} catch (ArrayIndexOutOfBoundsException ex) {
						}
						try {
							imagemDil3d[((i))][j + aux][k] = RECONSTRUCAO;
						} catch (ArrayIndexOutOfBoundsException ex) {
						}
						try {
							imagemDil3d[((i))][j][k + aux] = RECONSTRUCAO;
						} catch (ArrayIndexOutOfBoundsException ex) {
						}
						try {
							imagemDil3d[((i + aux))][j+aux][k] = RECONSTRUCAO;
						} catch (ArrayIndexOutOfBoundsException ex) {
						}
						try {
							imagemDil3d[((i + aux))][j - aux][k] = RECONSTRUCAO;
						} catch (ArrayIndexOutOfBoundsException ex) {
						}
						try {
							imagemDil3d[i][j+aux][k+aux] = RECONSTRUCAO;
						} catch (ArrayIndexOutOfBoundsException ex) {
						}
						try {
							imagemDil3d[i][j+aux][k-aux] = RECONSTRUCAO;
						} catch (ArrayIndexOutOfBoundsException ex) {
						}
						try {
							imagemDil3d[i+aux][j][k+aux] = RECONSTRUCAO;
						} catch (ArrayIndexOutOfBoundsException ex) {
						}
						try {
							imagemDil3d[i+aux][j][k-aux] = RECONSTRUCAO;
						} catch (ArrayIndexOutOfBoundsException ex) {
						}				
						try {
							imagemDil3d[i+aux][j+aux][k+aux] = RECONSTRUCAO;
						} catch (ArrayIndexOutOfBoundsException ex) {
						}
						try {
							imagemDil3d[i-aux][j+aux][k+aux] = RECONSTRUCAO;
						} catch (ArrayIndexOutOfBoundsException ex) {
						}
						try {
							imagemDil3d[i+aux][j-aux][k+aux] = RECONSTRUCAO;
						} catch (ArrayIndexOutOfBoundsException ex) {
						}
						try {
							imagemDil3d[i+aux][j+aux][k-aux] = RECONSTRUCAO;
						} catch (ArrayIndexOutOfBoundsException ex) {
						}
						lista2.insere(i, j, k);
					}
					lista.retira();

				}
			} else {
				for (int j = largura - 1; (j > largura - 1 - RECONSTRUCAO)
						&& (j >= 0); j--) {

					for (int i = 0; i < altura; i++) {

						for (int k = 0; k < nImag; k++) {

							if (imagemRec3d[(i * largura) + j][k] == RECONSTRUCAO - 1
									|| imagemRec3d[(i * largura) + j][k] == -1) {
								if (RECONSTRUCAO == 1
										&& imagemRec3d[(i * largura) + j][k] == 0) { // primeira
																						// exec.
									continue;
								}
								for (int aux = -1; aux < 2; aux += 2) {
									try {
										imagemDil3d[((i + aux))][j][k] = RECONSTRUCAO;
									} catch (ArrayIndexOutOfBoundsException ex) {
									}
									try {
										imagemDil3d[((i))][j + aux][k] = RECONSTRUCAO;
									} catch (ArrayIndexOutOfBoundsException ex) {
									}
									try {
										imagemDil3d[((i))][j][k + aux] = RECONSTRUCAO;
									} catch (ArrayIndexOutOfBoundsException ex) {
									}
									try {
										imagemDil3d[((i + aux))][j+aux][k] = RECONSTRUCAO;
									} catch (ArrayIndexOutOfBoundsException ex) {
									}
									try {
										imagemDil3d[((i + aux))][j - aux][k] = RECONSTRUCAO;
									} catch (ArrayIndexOutOfBoundsException ex) {
									}
									try {
										imagemDil3d[i][j+aux][k+aux] = RECONSTRUCAO;
									} catch (ArrayIndexOutOfBoundsException ex) {
									}
									try {
										imagemDil3d[i][j+aux][k-aux] = RECONSTRUCAO;
									} catch (ArrayIndexOutOfBoundsException ex) {
									}
									try {
										imagemDil3d[i+aux][j][k+aux] = RECONSTRUCAO;
									} catch (ArrayIndexOutOfBoundsException ex) {
									}
									try {
										imagemDil3d[i+aux][j][k-aux] = RECONSTRUCAO;
									} catch (ArrayIndexOutOfBoundsException ex) {
									}
									try {
										imagemDil3d[i+aux][j+aux][k+aux] = RECONSTRUCAO;
									} catch (ArrayIndexOutOfBoundsException ex) {
									}
									try {
										imagemDil3d[i-aux][j+aux][k+aux] = RECONSTRUCAO;
									} catch (ArrayIndexOutOfBoundsException ex) {
									}
									try {
										imagemDil3d[i+aux][j-aux][k+aux] = RECONSTRUCAO;
									} catch (ArrayIndexOutOfBoundsException ex) {
									}
									try {
										imagemDil3d[i+aux][j+aux][k-aux] = RECONSTRUCAO;
									} catch (ArrayIndexOutOfBoundsException ex) {
									}
									lista2.insere(i, j, k);
								}

							}
						}
					}
				}
			}
			
			int i, j, k;
			while (lista2.cabeca != null) {

				i = lista2.cabeca.getI();
				j = lista2.cabeca.getJ();
				k = lista2.cabeca.getK();
				for (int aux = -1; aux < 2; aux += 2) {
					try {
						if (((imagemDil3d[i + aux][j][k] == RECONSTRUCAO)
								&& (imagemRec3d[((i + aux) * largura) + j][k] == 0) && (this.imagemRef[k][i
								+ aux][j] == (byte) 255))) {
							imagemRec3d[((i + aux) * largura) + j][k] = RECONSTRUCAO;
							lista.insere(i + aux, j, k);						
							teste = false;

						}
					} catch (ArrayIndexOutOfBoundsException ex) {

					}
					try {
						if (((imagemDil3d[i][j + aux][k] == RECONSTRUCAO)
								&& (imagemRec3d[(i * largura) + j + aux][k] == 0) && (this.imagemRef[k][i][j
								+ aux] == (byte) 255))) {
							imagemRec3d[(i * largura) + j + aux][k] = RECONSTRUCAO;
							lista.insere(i, j + aux, k);						
							teste = false;

						}
					} catch (ArrayIndexOutOfBoundsException ex) {

					}
					try {
						if (((imagemDil3d[i][j][k + aux] == RECONSTRUCAO)
								&& (imagemRec3d[(i * largura) + j][k + aux] == 0) && (this.imagemRef[k+aux][i][j] == (byte) 255))) {
							imagemRec3d[(i * largura) + j][k + aux] = RECONSTRUCAO;
							lista.insere(i, j, k + aux);
							teste = false;

						}
					} catch (ArrayIndexOutOfBoundsException ex) {

					}
					
					try {
						if (((imagemDil3d[i+aux][j + aux][k] == RECONSTRUCAO)
								&& (imagemRec3d[((i+aux) * largura) + j + aux][k] == 0) && (this.imagemRef[k][(i+aux)][j
								+ aux] == (byte) 255))) {
							imagemRec3d[((i+aux) * largura) + j + aux][k] = RECONSTRUCAO;
							lista.insere((i+aux), j + aux, k);						
							teste = false;

						}
					} catch (ArrayIndexOutOfBoundsException ex) {

					}
					try {
						if (((imagemDil3d[i+aux][j - aux][k] == RECONSTRUCAO)
								&& (imagemRec3d[((i+aux) * largura) + j - aux][k] == 0) && (this.imagemRef[k][(i - aux)][j
								+ aux] == (byte) 255))) {
							imagemRec3d[((i+aux) * largura) + j - aux][k] = RECONSTRUCAO;
							lista.insere((i+aux), j - aux, k);						
							teste = false;

						}
						} catch (ArrayIndexOutOfBoundsException ex) {

					}
					try {
						if (((imagemDil3d[i][j + aux][(k+aux)] == RECONSTRUCAO)
								&& (imagemRec3d[(i * largura) + j + aux][(k+aux)] == 0) && (this.imagemRef[(k+aux)][i][j
								+ aux] == (byte) 255))) {
							imagemRec3d[(i * largura) + j + aux][(k+aux)] = RECONSTRUCAO;
							lista.insere(i, j + aux, (k+aux));						
							teste = false;

						}
					} catch (ArrayIndexOutOfBoundsException ex) {

					}
					try {
						if (((imagemDil3d[i][j + aux][(k-aux)] == RECONSTRUCAO)
								&& (imagemRec3d[(i * largura) + j + aux][(k-aux)] == 0) && (this.imagemRef[(k-aux)][i][j
								+ aux] == (byte) 255))) {
							imagemRec3d[(i * largura) + j + aux][(k-aux)] = RECONSTRUCAO;
							lista.insere(i, j + aux, (k-aux));						
							teste = false;

						}
					} catch (ArrayIndexOutOfBoundsException ex) {

					}
					try {
						if (((imagemDil3d[i + aux][j][(k+aux)] == RECONSTRUCAO)
								&& (imagemRec3d[((i + aux) * largura) + j][(k+aux)] == 0) && (this.imagemRef[(k+aux)][i
								+ aux][j] == (byte) 255))) {
							imagemRec3d[((i + aux) * largura) + j][(k+aux)] = RECONSTRUCAO;
							lista.insere(i + aux, j, (k+aux));						
							teste = false;

						}
					} catch (ArrayIndexOutOfBoundsException ex) {

					}
					try {
						if (((imagemDil3d[i + aux][j][(k-aux)] == RECONSTRUCAO)
								&& (imagemRec3d[((i + aux) * largura) + j][(k-aux)] == 0) && (this.imagemRef[(k-aux)][i
								+ aux][j] == (byte) 255))) {
							imagemRec3d[((i + aux) * largura) + j][(k-aux)] = RECONSTRUCAO;
							lista.insere(i + aux, j, (k-aux));						
							teste = false;

						}
					} catch (ArrayIndexOutOfBoundsException ex) {

					}
					try {
						if (((imagemDil3d[i + aux][j+aux][(k+aux)] == RECONSTRUCAO)
								&& (imagemRec3d[((i + aux) * largura) + j+aux][(k+aux)] == 0) && (this.imagemRef[(k+aux)][i
								+ aux][j+aux] == (byte) 255))) {
							imagemRec3d[((i + aux) * largura) + j+aux][(k+aux)] = RECONSTRUCAO;
							lista.insere(i + aux, j+aux, (k+aux));						
							teste = false;

						}
					} catch (ArrayIndexOutOfBoundsException ex) {

					}
					try {
						if (((imagemDil3d[i - aux][j+aux][(k+aux)] == RECONSTRUCAO)
								&& (imagemRec3d[((i - aux) * largura) + j+aux][(k+aux)] == 0) && (this.imagemRef[(k+aux)][i
								- aux][j+aux] == (byte) 255))) {
							imagemRec3d[((i - aux) * largura) + j+aux][(k+aux)] = RECONSTRUCAO;
							lista.insere(i - aux, j+aux, (k+aux));						
							teste = false;

						}
					} catch (ArrayIndexOutOfBoundsException ex) {

					}
					try {
						if (((imagemDil3d[i + aux][j-aux][(k+aux)] == RECONSTRUCAO)
								&& (imagemRec3d[((i + aux) * largura) + j-aux][(k+aux)] == 0) && (this.imagemRef[(k+aux)][i
								+ aux][j-aux] == (byte) 255))) {
							imagemRec3d[((i + aux) * largura) + j-aux][(k+aux)] = RECONSTRUCAO;
							lista.insere(i + aux, j-aux, (k+aux));						
							teste = false;

						}
					} catch (ArrayIndexOutOfBoundsException ex) {

					}
					try {
						if (((imagemDil3d[i + aux][j+aux][(k-aux)] == RECONSTRUCAO)
								&& (imagemRec3d[((i + aux) * largura) + j+aux][(k-aux)] == 0) && (this.imagemRef[(k-aux)][i
								+ aux][j+aux] == (byte) 255))) {
							imagemRec3d[((i + aux) * largura) + j+aux][(k-aux)] = RECONSTRUCAO;
							lista.insere(i + aux, j+aux, (k-aux));						
							teste = false;

						}
					} catch (ArrayIndexOutOfBoundsException ex) {

					}
					lista2.retira();
				}
			}
		

		if (teste) {
			this.t = false;
		}
		
		}
		
	}
	
	public void calcularTortuosidade() {

		int i;
		medias = new BigDecimal[largura];
		bar.setMaximum(largura);

		for (int j = largura - 1; j >= 0; j--) {
			BigDecimal aux = new BigDecimal("0.0");
			medias[largura - 1 - j] = new BigDecimal("0.0");
			for (i = 0; i < altura; i++) {
				for (int k = 0; k < imagemRec3d[0].length; k++) {
					if (imagemRec3d[(i * largura) + j][k] > 0) {
						aux = aux.add(new BigDecimal("1.0"));
						medias[largura - 1 - j] = medias[largura - 1 - j]
								.add(new BigDecimal(imagemRec3d[(i * largura)
										+ j][k]));

						somaX = somaX.add(new BigDecimal(Integer
								.toString(largura - 1 - j)));

						somaXquadr = somaXquadr.add(new BigDecimal(Integer
								.toString(largura - 1 - j)).pow(2));
						somaY = somaY.add(new BigDecimal(Integer
								.toString(imagemRec3d[(i * largura) + j][k])));
						somaXY = somaXY
								.add(new BigDecimal(Integer.toString(largura
										- 1 - j)).multiply((new BigDecimal(
										Integer.toString(imagemRec3d[(i * largura)
												+ j][k])))));

						m = m.add(new BigDecimal("1.0"));
					}
				}
			}
			if (0 != aux.compareTo(new BigDecimal("0.0"))) {
				medias[largura - 1 - j] = medias[largura - 1 - j].divide(aux,
						9, RoundingMode.HALF_UP);
			}
			bar.setValue(largura - j);

		}

		// CONTINUAR A PARTIR DAQUI
		int res = (m.compareTo(new BigDecimal("0.0")));
		if (res == 0) {
			a1 = new BigDecimal("0.0");
			a0 = new BigDecimal("0.0");
			return;
		}
		a1 = (somaXY.subtract((somaX.multiply(somaY)).divide(m, 9,
				RoundingMode.HALF_UP))).divide(somaXquadr.subtract((somaX
				.pow(2)).divide(m, 9, RoundingMode.HALF_UP)), 9,
				RoundingMode.HALF_UP);
		a0 = (somaY.divide(m, 9, RoundingMode.HALF_UP)).subtract(a1
				.multiply(somaX.divide(m, 9, RoundingMode.HALF_UP)));

		m = new BigDecimal("0.0");
		Yb = new BigDecimal("0.0");
		Xb = new BigDecimal("0.0");
		somaX = new BigDecimal("0.0");
		somaXquadr = new BigDecimal("0.0");
		somaY = new BigDecimal("0.0");
		somaXY = new BigDecimal("0.0");
		for (int j = 1; j < medias.length; j++) {
			if (0 == medias[j].compareTo(new BigDecimal("0.0"))) {
				break;
			}
			somaX = somaX.add(new BigDecimal(Integer.toString(j)));

			somaXquadr = somaXquadr.add(new BigDecimal(Integer.toString(j))
					.pow(2));
			somaY = somaY.add(medias[j]);
			somaXY = somaXY.add(new BigDecimal(Integer.toString(j))
					.multiply(medias[j]));

			m = m.add(new BigDecimal("1.0"));

		}

		res = (m.compareTo(new BigDecimal("0.0")));
		if (res == 0) {
			A1 = new BigDecimal("0.0");
			A0 = new BigDecimal("0.0");
			return;
		}
		A1 = (somaXY.subtract((somaX.multiply(somaY)).divide(m, 9,
				RoundingMode.HALF_UP))).divide(somaXquadr.subtract((somaX
				.pow(2)).divide(m, 9, RoundingMode.HALF_UP)), 9,
				RoundingMode.HALF_UP);
		A0 = (somaY.divide(m, 9, RoundingMode.HALF_UP)).subtract(A1
				.multiply(somaX.divide(m, 9, RoundingMode.HALF_UP)));
		

	}

	public void preencheGrafico() {
		if(dataset!=null){
			this.showGraph(this.largura);
			return;
		}
		dataset = new XYSeriesCollection();
		pontosReconstruidos = new XYSeries("Distribution");

		dataset2 = new XYSeriesCollection();
		retaMelhorAjusteDis = new XYSeries("Best Fit Line");

		
		dataset.addSeries(pontosReconstruidos);
		dataset2.addSeries(retaMelhorAjusteDis);
		dataset4 = new XYSeriesCollection();
		retaMelhorAjusteMed = new XYSeries("Best Fit Line");
		
		dataset3 = new XYSeriesCollection();
		tortuosidadeMed = new XYSeries("Mean <Le,Lg>");
		
		dataset3.addSeries(tortuosidadeMed);
		dataset4.addSeries(retaMelhorAjusteMed);

		this.showGraph(this.largura);
		
		for (int j = largura - 1; j > 0; j--) {
			for (int i = 0; i < altura; i++) {
				for (int k = 0; k < imagemRec3d[0].length; k++) {

					if (imagemRec3d[(i * largura) + j][k] > 0) {
						pontosReconstruidos.add(largura - 1 - j,
								imagemRec3d[(i * largura) + j][k]);

					}

				}
			}
		}

		for (int j = 1; j < medias.length; j++) {

			if (0 == medias[j].compareTo(new BigDecimal("0.0"))) {
				break;
			} else {
				tortuosidadeMed.add(j, medias[j].floatValue());
			}

		}
		
		
		retaMelhorAjusteDis.add(.0f, a0.floatValue());
		retaMelhorAjusteDis.add(largura, a0.floatValue() + a1.floatValue()
				* largura);
		
		
		retaMelhorAjusteMed.add(.0f, A0.floatValue());
		retaMelhorAjusteMed.add(largura, A0.floatValue() + A1.floatValue()
				* largura);

		
		

	

		retaMelhorAjusteMed.add(.0f, A0.floatValue());
		retaMelhorAjusteMed.add(largura, A0.floatValue() + A1.floatValue()
				* largura);
	
	}

}
