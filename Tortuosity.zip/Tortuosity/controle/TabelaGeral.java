package controle;


import javax.swing.table.AbstractTableModel;

public class TabelaGeral extends AbstractTableModel {

	Imagem[] ima;
	
	public TabelaGeral(Imagem[] im){
		ima=im;
			}
	@Override
	public String getColumnName(int column) {
		   switch (column) {
		   case 0:
		     return "Direction";
		   case 1:
		     return "T (Distribution)";
		   case 2:
			 return "T (Mean)";
		   }
		   return "";
		 }
	
	public int getRowCount() {
		// TODO Auto-generated method stub
		return ima.length;
	}

	@Override
	public int getColumnCount() {
		// TODO Auto-generated method stub
		return 3;
	}

	@Override
	public Object getValueAt(int linha, int coluna) {
		    
		     switch(coluna) {
		     case 0:

		    	 return ima[linha].orientacao;
		    	 
		     
		     case 1:
		    		
		    	 return ima[linha].a1.doubleValue();
		     
		     case 2:	 
		    
		    	 return ima[linha].A1.doubleValue();	 
		      
		    	 default:
		    		 
		    		 return "######";
		     }
		    
		   }
	
	}
