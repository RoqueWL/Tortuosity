package controle;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
*/
import ij.IJ;
import ij.ImagePlus;
import ij.process.ShortProcessor;

import java.math.BigDecimal;
import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JTabbedPane;
import javax.swing.JTable;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYDotRenderer;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;


public abstract class Imagem {
  // protected int imagemDil3d[][][];
 //  int nb;  
   
   /*
    * 
    *  
    *  Reduriz o consumo de memória de cada direção!
    *  
    *  
    *  
   */
	 protected JFreeChart chart;
	 protected JFreeChart chart2;
	 protected ChartPanel chartPanel;
	 protected ChartPanel chartPanel2;
	 protected ThreadCalcular thread;
	 protected boolean imagemRec3d[][][];
   XYSeriesCollection dataset, dataset2, dataset3, dataset4;  
  XYSeries retaMelhorAjusteDis;
  XYSeries tortuosidadeMed;
  XYSeries retaMelhorAjusteMed;
   XYSeries pontosReconstruidos;
	 // Plot plot, plot1; 
	  XYPlot plot, plot1;
  // Plot plot, plot1; 
	TLista lista, lista2;
	protected BigDecimal medias[];
   // protected int imagemRec3d[][];
   // protected int imagemOrig3d[][];
   public byte imagemRef[][][];
   protected int d;
    public int largura;
	public int altura;
	public int nImag;
   protected BigDecimal a1;
   protected BigDecimal a0;
   protected BigDecimal A1;
   protected BigDecimal A0;
   protected boolean t = true;
 //   int BLACK = Color.BLACK.getRGB();
  //  int WHITE = Color.WHITE.getRGB();
  protected BigDecimal aux_med[];
    protected BigDecimal m = new BigDecimal("0.0");
    protected BigDecimal Yb = new BigDecimal("0.0");
    protected BigDecimal Xb = new BigDecimal("0.0");
    protected BigDecimal somaX = new BigDecimal("0.0");
    protected BigDecimal somaXquadr = new BigDecimal("0.0");
    protected BigDecimal somaY = new BigDecimal("0.0");
    protected BigDecimal somaXY = new BigDecimal("0.0");
    boolean grafico;
    public JTable tabela;
    JProgressBar bar;
    JLabel progresso;
    JTabbedPane tabbedPane;
    public String orientacao;
   int EE;
//JLabel bel=null;
    public Imagem(String orientacao,int largura, int altura, int nImag, byte im[][][], JProgressBar bar, JLabel progresso, JTable tabela, JTabbedPane tabbedPane) {
        t = true;
        this.tabbedPane=tabbedPane;
        this.orientacao=orientacao;
        this.bar=bar;
        this.progresso=progresso;
     //   this.nb=nb;
        this.imagemRef = im;
        this.altura = altura;
        this.largura = largura;  
        this.nImag= nImag;
        this.tabela=tabela;
       
     
    }

    public abstract boolean reconstr(int EE, ThreadCalcular thread);
    
    public abstract void calcularTortuosidade();

    public abstract void dilata(int EE, int RECONSTRUCAO);
    
  public void preencheGrafico(){
	  
    }
    
    
public int getReconstrucao(){
	return d;
}
    public BigDecimal getA1() {
        return a1;
    }

    public BigDecimal getA0() {
        return a0;
    }
    
  /*  public void exibeText(){
    	
    //	textArea.append("A0 :"+A0.doubleValue());
    	textArea.append("\nA1 ( τ ) pela média  :"+A1.doubleValue());
    //	textArea.append("\na0 :"+a0.doubleValue());
    	textArea.append("\na1 ( τ ) pela distribuição :"+a1.doubleValue());
    	textArea.append("\nreconstrs :"+d);
    	 	
    	
    	
    }*/
    
   // public abstract void enabledTab(int NumTab);
    
  /*  
    public void escreveRec(String direcao, int reconstrucoes){
    	String format="txt";
    	String dir2 = IJ.getDirectory("Onde salvar as reconstruções da direção "+direcao+"?");
    	String caminho = dir2 + "\\"+direcao;

         if (!new File(caminho).exists()) { // Verifica se o diretório existe.   
             (new File(caminho)).mkdir();   // Cria o diretório   
         }

         ImagePlus imagem;
         String ajuste = ajuste(imagemRec3d.length);
         
      
         
         for (int k = 0, ind = 0; k < imagemRec3d.length; k++, ind++) {

           
            String novo = caminho + "\\"+direcao+"(" + (String.format(ajuste, ind)) + ")."+format; // o numero de zeros a esquerda aina pode variar
            
  
               	  ShortProcessor ip2=new ShortProcessor(largura, altura);
             ip2.setPixels(imagemRec3d[k]);
             imagem= new ImagePlus(direcao+"(" + (String.format(ajuste, ind)) + ")", ip2);

            	IJ.saveAs(imagem, format, novo);
         
 }
       
         IJ.log("Reconstruções "+direcao+" escritas.");
    }
 */   
    
    public void showGraph(int LarguraGrafico) {  
        chart = createChart(false,dataset, dataset2, LarguraGrafico);  
        chart2 = createChart(true,dataset3, dataset4, LarguraGrafico);  
       // chart.getRenderingHints().put
       // (RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
       // chart.setBackgroundPaint( Color.red ); 
      
        chartPanel = new ChartPanel(chart,true);  
        //chartPanel.setPreferredSize(new java.awt.Dimension(570, 570));  
        chartPanel2 = new ChartPanel(chart2, true);  
        //chartPanel2.setPreferredSize(new java.awt.Dimension(570, 570));  
    
        
        //final ApplicationFrame frame = new ApplicationFrame("Title");  
        //final ApplicationFrame frame2 = new ApplicationFrame("Title");  
        
        JFrame frame = new JFrame("Tortuosity");//
        
       
        JPanel painelPrincipal = new JPanel();
        painelPrincipal.setLayout(new BorderLayout());
        frame.add(painelPrincipal);
        //("Distribuição "+orientacao+".");  
      //  JFrame frame2 = new JFrame("Media "+orientacao+".");  
        
        JTabbedPane abas = new JTabbedPane();
        abas.addTab("Distribution", null);
        abas.addTab("Mean", null);
        painelPrincipal.add(abas);
        abas.setComponentAt(0, chartPanel);
        abas.setComponentAt(1, chartPanel2);
        frame.setPreferredSize(new java.awt.Dimension(LarguraGrafico+90, this.getReconstrucao()+140));
        
       // frame.setLayout(new FlowLayout()); 
       
        /*
        frame.setContentPane(chartPanel);
        frame2.setContentPane(chartPanel2);
         
        frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        frame2.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        
        
        frame.pack();
        frame2.pack();
        
        frame.setVisible(true);
        frame2.setVisible(true);
        
       // frame2.setSize(600, 600);  
       // frame2.setLayout(new FlowLayout());  
       // frame2.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
       // frame2.add(chartPanel2);
       
        //frame2.setVisible(true);
         * 
         * 
         */
        
        frame.pack();
        //frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        frame.setDefaultCloseOperation((JFrame.DISPOSE_ON_CLOSE));
        frame.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosed(WindowEvent e) {
				
				
//				dataset.removeSeries(0);

			    Imagem.this.pontosReconstruidos.clear();
	//			dataset2.removeSeries(0);
				
		//		dataset3.removeSeries(0);
			//	dataset4.removeSeries(0);
				
				
				System.gc();
				/*
				 * 
				 * Resolver o lixo visual
				 */
			}
		});
        frame.setVisible(true);
    }  
  
    private JFreeChart createChart(boolean med,final XYDataset dataset,final XYDataset dataset2, int largura_grafico) {  
        final JFreeChart chart = ChartFactory.createScatterPlot(  
        		orientacao,                  // chart title  
            "Le",                      // x axis label  
            "Lg",                      // y axis label  
            null,                  // data  
            PlotOrientation.VERTICAL,  
            true,                     // include legend  
            true,                     // tooltips  
            false                     // urls  
        );  
          // chart.setTitle();
        // Comentando essas linhas abaixo;  

        plot = (XYPlot) chart.getPlot();  
        NumberAxis domain = (NumberAxis) plot.getDomainAxis();
        domain.setRange(0.00, largura_grafico);
        ValueAxis axis = plot.getRangeAxis();
        if(med){
        	if(this.A0.floatValue()<0){
           	 axis.setRange(this.A0.floatValue()-10, this.getReconstrucao());
           }else{
           	 axis.setRange(-10, this.getReconstrucao());
           }	
        }else{
        	if(this.a0.floatValue()<0){
              	 axis.setRange(this.a0.floatValue()-10, this.getReconstrucao());
              }else{
              	 axis.setRange(-10, this.getReconstrucao());
              }	
        }
        
        
       
        plot.setRangeGridlinesVisible(false);
        plot.setDomainGridlinesVisible(false);
        
      //  COLOCAR O EIXO X COM O MESMO VALOR DA MAIOR DISTANCIA GEODESICA
        plot.setBackgroundPaint( Color.WHITE ); 
       
        plot.setDataset(0, dataset2);
        XYLineAndShapeRenderer renderer = new XYLineAndShapeRenderer();//new XYDotRenderer();
      //  renderer.set
        renderer.setSeriesPaint( 0 , Color.RED );
      
        plot.setDataset(1, dataset);
        renderer.setSeriesLinesVisible(1, true);
        renderer.setSeriesStroke( 0 , new BasicStroke( 1 ) );
        renderer.setSeriesShapesVisible(1, false);
      //  renderer.setSeriesStroke(1,new BasicStroke(2));
        
       // plot.setRenderer(0,
        if(med){//med){
        	/*XYLineAndShapeRenderer renderer2 = new XYLineAndShapeRenderer();//new XYDotRenderer();
        	renderer2.setSeriesPaint( 1 , Color.GREEN );
            renderer2.setSeriesLinesVisible(1, true);
        //    renderer.setSeriesStroke( 1 , new BasicStroke( 1.0f ) );
            renderer2.setSeriesShapesVisible(1, false);
          /*/ 
            XYDotRenderer dc= new XYDotRenderer();
        	dc.setSeriesPaint(0, Color.BLACK);
        	 dc.setSeriesStroke( 0 , new BasicStroke( 5.0f ) );
        	plot.setRenderer(1, dc);
       
            
        //	plot.setRenderer(1, renderer2);
        }else{
        	XYDotRenderer dc= new XYDotRenderer();
        	dc.setSeriesPaint(0, Color.BLACK);
       // 	 dc.setSeriesStroke( 1 , new BasicStroke( 2.0f ) );
        	plot.setRenderer(1, dc);
        }
        plot.setRenderer(0, renderer);
        
        // Até aqui  
  
        return chart;  
    }  
    
    private static String ajuste(int aux) {

        int i = 1;
        while (aux >= 1) {
            aux /= 10;
            i++;
        }
        return "%0" + i + "d";
    }
    public void enabledTab(int numTab, long time){
    	this.tabbedPane.setToolTipTextAt(numTab, time + " ms");  
    	this.tabbedPane.setEnabledAt(numTab, true);
	 	  
		
	}
   }
