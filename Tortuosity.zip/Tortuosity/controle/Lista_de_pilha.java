package controle;

import ij.IJ;
import ij.ImageJ;
import ij.ImagePlus;
import ij.WindowManager;
import ij.plugin.PlugIn;

public class Lista_de_pilha implements PlugIn {
	
	ImagePlus imp;
	public static void main(String arg[]){
		ImageJ IJ1 = new ImageJ(1);
	}
	
	public void run(String arg) {
		// TODO Auto-generated method stub
		
		int n=WindowManager.getImageCount();
		IJ.log("tamanho: "+n);
		int ids[]=WindowManager.getIDList();
		 for (int i=0; i<ids.length; i++) {
			 ImagePlus imp = WindowManager.getImage(ids[i]);
           
             IJ.log(i + " " + imp.getTitle() + (imp==WindowManager.getCurrentImage()?"*":""));
             IJ.log(imp.getWidth()+" x "+imp.getHeight()+" x "+imp.getStackSize());
         }
	}

}
