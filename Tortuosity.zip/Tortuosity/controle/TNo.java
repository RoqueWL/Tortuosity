package controle;

public class TNo {
	
	public int I, J, K;
	public TNo proximo;
	
		
	public int getI() {
		return I;
	}

	public int getJ() {
		return J;
	}

	public int getK() {
		return K;
	}

	public TNo(){
		this.proximo=null;
		
	}
	
	public TNo(TNo no, int i, int j, int k){
		this.proximo=no;
		this.I=i;
		this.J=j;
		this.K=k;
	}
	
	public TNo(TNo no, TNo no2){
		this.proximo=no;
		this.I=no2.getI();
		this.J=no2.getJ();
		this.K=no2.getK();
		no2=null;
	}
	
	
	public TNo(int i, int j, int k){
		this.proximo=null;
		this.I=i;
		this.J=j;
		this.K=k;
	}
	
	
	

}
