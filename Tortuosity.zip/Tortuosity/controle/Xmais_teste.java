/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controle;


import ij.IJ;

import java.math.BigDecimal;
import java.math.RoundingMode;

import javax.swing.JLabel;
import javax.swing.JProgressBar;
import javax.swing.JTabbedPane;
import javax.swing.JTable;

import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;


import controle.Imagem;

/**
 * 
 * @author UFPB-CIA-03
 */
public class Xmais_teste extends Imagem {

	// boolean imagemRec3d[][][];
	 //boolean grafico;
	 boolean teste;
	public Xmais_teste(int w, int h, int nImag, byte[][][] im, JProgressBar bar,
			JLabel progresso, JTable tabela, JTabbedPane tabbedPane) {
		super("(+X)", w, h, nImag, im, bar, progresso, tabela, tabbedPane);

	}

	public boolean reconstr(int EE, ThreadCalcular thread) {
		this.EE = EE;
		imagemRec3d = new boolean[altura][largura][imagemRef.length];
		grafico=false;
		
	
		//imagemDil3d = new int[altura][largura][imagemRef.length];
	//	imagemDil3d = new int[1][1][1];
		this.lista2 = new TLista();
		this.lista = new TLista();
		for (int i = 0; i < altura; i++) { 
			for (int k = 0; k < imagemRef.length; k++) {

				if( imagemRef[k][i][0] == (byte) 255){
					imagemRec3d[i][0][k] =true;
					lista2.insere(i, 0, k);
				}
				

			}
		}
		medias = new BigDecimal[largura];
		aux_med = new BigDecimal[largura];
		for(int j=0;j<largura;j++){
		medias[j]=new BigDecimal("0.0");
		aux_med[j]=new BigDecimal("0.0");
		}
		d = 0;
		progresso.setText("Reconstructing +X");
		bar.setIndeterminate(true);
		/////////////////////
		
		retaMelhorAjusteDis = new XYSeries("Best Fit Line", false);
		tortuosidadeMed = new XYSeries("Mean <Le,Lg>", false);
		retaMelhorAjusteMed = new XYSeries("Best Fit Line", false);
		pontosReconstruidos = new XYSeries("Distribution", false);
		
		///////////////////
		while (t&&!Thread.currentThread().isInterrupted()) {
			
			 bar.setString("Rec: "+d);
			dilata(EE, d);

			// IJ.showStatus(" "+d);

			d+=2;

		}
		if(t){
			return true;
		}
		d--;
		bar.setIndeterminate(false);
		progresso.setText("+X ");
		//bar.setString("Rec: " + d);
		a1 = new BigDecimal("0.0");
		a0 = new BigDecimal("0.0");
		/*	IJ.log("soma XY"+somaXY.intValue());
		IJ.log("soma Y"+somaY.intValue());
		IJ.log("somaXquadr"+somaXquadr.intValue());
		IJ.log("Qtd pontos: "+m.intValue());
		*/
		int res = (m.compareTo(new BigDecimal("0.0")));
		if (res == 0) {
			a1 = new BigDecimal("0.0");
			a0 = new BigDecimal("0.0");
			return true;
		}
		a1 = (somaXY.subtract((somaX.multiply(somaY)).divide(m, 9,
				RoundingMode.HALF_UP))).divide(somaXquadr.subtract((somaX
				.pow(2)).divide(m, 9, RoundingMode.HALF_UP)), 9,
				RoundingMode.HALF_UP);
		a0 = (somaY.divide(m, 9, RoundingMode.HALF_UP)).subtract(a1
				.multiply(somaX.divide(m, 9, RoundingMode.HALF_UP)));
		
		
		m = new BigDecimal("0.0");
		Yb = new BigDecimal("0.0");
		Xb = new BigDecimal("0.0");
		somaX = new BigDecimal("0.0");
		somaXquadr = new BigDecimal("0.0");
		somaY = new BigDecimal("0.0");
		somaXY = new BigDecimal("0.0");
		for (int j = 1; j < medias.length; j++) {
			if (0 == medias[j].compareTo(new BigDecimal("0.0"))) {
				break;
			}
			
				medias[j] = medias[j].divide(aux_med[j], 9, RoundingMode.HALF_UP);
				tortuosidadeMed.add(j, medias[j].floatValue());

			somaX = somaX.add(new BigDecimal(Integer.toString(j)));

			somaXquadr = somaXquadr.add(new BigDecimal(Integer.toString(j))
					.pow(2));
			somaY = somaY.add(medias[j]);
			somaXY = somaXY.add(new BigDecimal(Integer.toString(j))
					.multiply(medias[j]));

			m = m.add(new BigDecimal("1.0"));

		}
		res = (m.compareTo(new BigDecimal("0.0")));
		if (res == 0) {
			 System.out.print("m deu zero");
			A1 = new BigDecimal("0.0");
			A0 = new BigDecimal("0.0");
			return false;
		}
		A1 = (somaXY.subtract((somaX.multiply(somaY)).divide(m, 9,
				RoundingMode.HALF_UP))).divide(somaXquadr.subtract((somaX
				.pow(2)).divide(m, 9, RoundingMode.HALF_UP)), 9,
				RoundingMode.HALF_UP);
		A0 = (somaY.divide(m, 9, RoundingMode.HALF_UP)).subtract(A1
				.multiply(somaX.divide(m, 9, RoundingMode.HALF_UP)));

		retaMelhorAjusteDis.add(0.0, a0.floatValue());
		retaMelhorAjusteDis.add(largura, a0.floatValue() + a1.floatValue()
				* largura);
		
		retaMelhorAjusteMed.add(.0f, A0.floatValue());
		retaMelhorAjusteMed.add(largura, A0.floatValue() + A1.floatValue()
				* largura);
return false;
		//this.showGraph(this.largura);
	}

	public void consulta(int i, int j, int k, int RECONSTRUCAO){
		try {
			if(imagemRef[k][(i)][j] == (byte)255 && imagemRec3d[i][j][k] == false){
				imagemRec3d[(i)][j][k]=true;
				if(grafico){
				pontosReconstruidos.addOrUpdate(j, RECONSTRUCAO);
				lista2.insere(i, j, k);
				teste=false;
				return;
				}
				aux_med[j]=aux_med[j].add(new BigDecimal("1.0"));//////////////
				this.medias[j]=this.medias[j].add(new BigDecimal(RECONSTRUCAO));
				somaX = somaX.add(new BigDecimal(Integer.toString(j)));
				lista2.insere(i, j, k);
				somaXquadr = somaXquadr.add(new BigDecimal(Integer
						.toString(j)).pow(2));
				somaY = somaY.add(new BigDecimal(Integer
						.toString(RECONSTRUCAO)));
				somaXY = somaXY
						.add(new BigDecimal(Integer.toString(j)).multiply((new BigDecimal(
								Integer.toString(RECONSTRUCAO)))));

				m = m.add(new BigDecimal("1.0"));
				teste=false;
			}
		} catch (ArrayIndexOutOfBoundsException ex) {
		}
		
	}
	public void consulta2(int i, int j, int k, int RECONSTRUCAO){
		try {
			if(imagemRef[k][(i)][j] == (byte)255 && imagemRec3d[i][j][k] == false){
				//////////////
				imagemRec3d[(i)][j][k]=true;
				if(grafico){
					pontosReconstruidos.addOrUpdate(j, RECONSTRUCAO);
					lista.insere(i, j, k);
					teste=false;
					return;
					}
				aux_med[j]=aux_med[j].add(new BigDecimal("1.0"));
				this.medias[j]=this.medias[j].add(new BigDecimal(RECONSTRUCAO));
				somaX = somaX.add(new BigDecimal(Integer.toString(j)));
				lista.insere(i, j, k);
				somaXquadr = somaXquadr.add(new BigDecimal(Integer
						.toString(j)).pow(2));
				somaY = somaY.add(new BigDecimal(Integer
						.toString(RECONSTRUCAO)));
				somaXY = somaXY
						.add(new BigDecimal(Integer.toString(j)).multiply((new BigDecimal(
								Integer.toString(RECONSTRUCAO)))));

				m = m.add(new BigDecimal("1.0"));
				teste=false;
			}
		} catch (ArrayIndexOutOfBoundsException ex) {
		}
		
}
	public void dilata(int EE, int RECONSTRUCAO) {
		 teste = true;
		
		if (EE == 4) {
			
				int i, j, k=0;
				while (lista.cabeca != null) {

					i = lista.cabeca.getI();
					j = lista.cabeca.getJ();
					
					for (int aux = -1; aux < 2; aux += 2) {
					
					consulta(i+aux,j,k,RECONSTRUCAO);
					consulta(i,j+aux,k,RECONSTRUCAO);
					
					}
					lista.retira();

				}
			 
			
			
			
				if(lista2.cabeca != null){
					RECONSTRUCAO++;	
				}
				
				while (lista2.cabeca != null) {
					
					i = lista2.cabeca.getI();
					j = lista2.cabeca.getJ();
					
					for (int aux = -1; aux < 2; aux += 2) {
						

						consulta2(i+aux,j,k,RECONSTRUCAO);
						consulta2(i,j+aux,k,RECONSTRUCAO);
						
					
						
					}
					lista2.retira();
					
				}
			
				
			if (teste) {
				this.d--;
				this.t = false;
			}
			
		}else if (EE == 6) {
			
				int i, j, k;
				while (lista.cabeca != null) {

					i = lista.cabeca.getI();
					j = lista.cabeca.getJ();
					k = lista.cabeca.getK();
					for (int aux = -1; aux < 2; aux += 2) {
						consulta(i+aux,j,k,RECONSTRUCAO);
						consulta(i,j+aux,k,RECONSTRUCAO);
						consulta(i,j,k+aux,RECONSTRUCAO);
						
					}
					lista.retira();

				}
		
			if(lista2.cabeca != null){
				RECONSTRUCAO++;	
			//	System.out.println("lista2 != null");
			}
			//	int i, j, k;
				while (lista2.cabeca != null) {

					i = lista2.cabeca.getI();
					j = lista2.cabeca.getJ();
					k = lista2.cabeca.getK();
				//	IJ.log("entrei3");
					for (int aux = -1; aux < 2; aux += 2) {
						
						consulta2(i+aux,j,k,RECONSTRUCAO);
						consulta2(i,j+aux,k,RECONSTRUCAO);
						consulta2(i,j,k+aux,RECONSTRUCAO);
					
					}
					lista2.retira();
				}
			

			if (teste) {
				this.d--;
				this.t = false;
			}
			
		} else if (EE == 18) {
			
			
				int i, j, k;
				while (lista.cabeca != null) {

					i = lista.cabeca.getI();
					j = lista.cabeca.getJ();
					k = lista.cabeca.getK();
					for (int aux = -1; aux < 2; aux += 2) {
						consulta(i+aux,j,k,RECONSTRUCAO);
						consulta(i,j+aux,k,RECONSTRUCAO);
						consulta(i,j,k+aux,RECONSTRUCAO);
						consulta(i+aux,j+aux,k,RECONSTRUCAO);
						consulta(i+aux,j-aux,k,RECONSTRUCAO);
						consulta(i,j+aux,k+aux,RECONSTRUCAO);
						consulta(i,j+aux,k-aux,RECONSTRUCAO);
						consulta(i+aux,j,k+aux,RECONSTRUCAO);
						consulta(i+aux,j,k-aux,RECONSTRUCAO);
						
					}
					lista.retira();

				}
		
			
			
			
			while (lista2.cabeca != null) {

				i = lista2.cabeca.getI();
				j = lista2.cabeca.getJ();
				k = lista2.cabeca.getK();
				for (int aux = -1; aux < 2; aux += 2) {
					consulta2(i+aux,j,k,RECONSTRUCAO);
					consulta2(i,j+aux,k,RECONSTRUCAO);
					consulta2(i,j,k+aux,RECONSTRUCAO);
					consulta2(i+aux,j+aux,k,RECONSTRUCAO);
					consulta2(i+aux,j-aux,k,RECONSTRUCAO);
					consulta2(i,j+aux,k+aux,RECONSTRUCAO);
					consulta2(i,j+aux,k-aux,RECONSTRUCAO);
					consulta2(i+aux,j,k+aux,RECONSTRUCAO);
					consulta2(i+aux,j,k-aux,RECONSTRUCAO);
				}
					lista2.retira();
				}
			
		

		if (teste) {
			this.t = false;
		}
			

		}else if(EE==26){
			
			
				int i, j, k;
				while (lista.cabeca != null) {

					i = lista.cabeca.getI();
					j = lista.cabeca.getJ();
					k = lista.cabeca.getK();
					for (int aux = -1; aux < 2; aux += 2) {
						consulta(i+aux,j,k,RECONSTRUCAO);
						consulta(i,j+aux,k,RECONSTRUCAO);
						consulta(i,j,k+aux,RECONSTRUCAO);
						consulta(i+aux,j+aux,k,RECONSTRUCAO);
						consulta(i+aux,j-aux,k,RECONSTRUCAO);
						consulta(i,j+aux,k+aux,RECONSTRUCAO);
						consulta(i,j+aux,k-aux,RECONSTRUCAO);
						consulta(i+aux,j,k+aux,RECONSTRUCAO);
						consulta(i+aux,j,k-aux,RECONSTRUCAO);
						consulta(i+aux,j+aux,k+aux,RECONSTRUCAO);
						consulta(i-aux,j+aux,k+aux,RECONSTRUCAO);
						consulta(i+aux,j-aux,k+aux,RECONSTRUCAO);
						consulta(i+aux,j+aux,k-aux,RECONSTRUCAO);
						
					}
					lista.retira();

				}
			
			
			
			while (lista2.cabeca != null) {

				i = lista2.cabeca.getI();
				j = lista2.cabeca.getJ();
				k = lista2.cabeca.getK();
				for (int aux = -1; aux < 2; aux += 2) {
					consulta2(i+aux,j,k,RECONSTRUCAO);
					consulta2(i,j+aux,k,RECONSTRUCAO);
					consulta2(i,j,k+aux,RECONSTRUCAO);
					consulta2(i+aux,j+aux,k,RECONSTRUCAO);
					consulta2(i+aux,j-aux,k,RECONSTRUCAO);
					consulta2(i,j+aux,k+aux,RECONSTRUCAO);
					consulta2(i,j+aux,k-aux,RECONSTRUCAO);
					consulta2(i+aux,j,k+aux,RECONSTRUCAO);
					consulta2(i+aux,j,k-aux,RECONSTRUCAO);
					consulta2(i+aux,j+aux,k+aux,RECONSTRUCAO);
					consulta2(i-aux,j+aux,k+aux,RECONSTRUCAO);
					consulta2(i+aux,j-aux,k+aux,RECONSTRUCAO);
					consulta2(i+aux,j+aux,k-aux,RECONSTRUCAO);
					
				}
				lista2.retira();
			}
		

		if (teste) {
			this.t = false;
		}
		
		}
		
	}

	public void calcularTortuosidade() {

		int i;// , p;
		medias = new BigDecimal[largura];
		bar.setMaximum(largura);
/*
		for (int j = 0; j < largura; j++) {
			BigDecimal aux = new BigDecimal("0.0");
			medias[j] = new BigDecimal("0.0");
			for (i = 0; i < altura; i++) {
				for (int k = 0; k < imagemRec3d[0].length; k++) {
					if (imagemRec3d[(i * largura) + j][k] > 0) {

						aux = aux.add(new BigDecimal("1.0"));
						medias[j] = medias[j].add(new BigDecimal(
								imagemRec3d[(i * largura) + j][k]));

						somaX = somaX.add(new BigDecimal(Integer.toString(j)));

						somaXquadr = somaXquadr.add(new BigDecimal(Integer
								.toString(j)).pow(2));
						somaY = somaY.add(new BigDecimal(Integer
								.toString(imagemRec3d[(i * largura) + j][k])));
						somaXY = somaXY
								.add(new BigDecimal(Integer.toString(j)).multiply((new BigDecimal(
										Integer.toString(imagemRec3d[(i * largura)
												+ j][k])))));

						m = m.add(new BigDecimal("1.0"));
					}
				}
				bar.setValue(j + 1);
			}
			if (0 != aux.compareTo(new BigDecimal("0.0"))) {
				medias[j] = medias[j].divide(aux, 9, RoundingMode.HALF_UP);
			}

		}
		*/
		int res = (m.compareTo(new BigDecimal("0.0")));
		if (res == 0) {
			a1 = new BigDecimal("0.0");
			a0 = new BigDecimal("0.0");
			return;
		}
		a1 = (somaXY.subtract((somaX.multiply(somaY)).divide(m, 9,
				RoundingMode.HALF_UP))).divide(somaXquadr.subtract((somaX
				.pow(2)).divide(m, 9, RoundingMode.HALF_UP)), 9,
				RoundingMode.HALF_UP);
		a0 = (somaY.divide(m, 9, RoundingMode.HALF_UP)).subtract(a1
				.multiply(somaX.divide(m, 9, RoundingMode.HALF_UP)));

		// IJ.log("tortuosidade " +orientacao+": EE "+EE+" - "+d+"\n"+
		// a1.toString() +"\n");

		m = new BigDecimal("0.0");
		Yb = new BigDecimal("0.0");
		Xb = new BigDecimal("0.0");
		somaX = new BigDecimal("0.0");
		somaXquadr = new BigDecimal("0.0");
		somaY = new BigDecimal("0.0");
		somaXY = new BigDecimal("0.0");
		for (int j = 1; j < medias.length; j++) {
			if (0 == medias[j].compareTo(new BigDecimal("0.0"))) {
				break;
			}
			somaX = somaX.add(new BigDecimal(Integer.toString(j)));

			somaXquadr = somaXquadr.add(new BigDecimal(Integer.toString(j))
					.pow(2));
			somaY = somaY.add(medias[j]);
			somaXY = somaXY.add(new BigDecimal(Integer.toString(j))
					.multiply(medias[j]));

			m = m.add(new BigDecimal("1.0"));

		}
		// System.out.println("chegou onde eu queria");

		res = (m.compareTo(new BigDecimal("0.0")));
		if (res == 0) {
			// System.out.print("m deu zero");
			A1 = new BigDecimal("0.0");
			A0 = new BigDecimal("0.0");
			return;
		}
		A1 = (somaXY.subtract((somaX.multiply(somaY)).divide(m, 9,
				RoundingMode.HALF_UP))).divide(somaXquadr.subtract((somaX
				.pow(2)).divide(m, 9, RoundingMode.HALF_UP)), 9,
				RoundingMode.HALF_UP);
		A0 = (somaY.divide(m, 9, RoundingMode.HALF_UP)).subtract(A1
				.multiply(somaX.divide(m, 9, RoundingMode.HALF_UP)));

		// table.setModel(new TabelaAbas(this));

	}

	public void preencheGrafico() {
		if(dataset!=null){
			this.showGraph(this.largura);
			return;
		}
		dataset = new XYSeriesCollection();
		dataset2 = new XYSeriesCollection();
		dataset2.addSeries(retaMelhorAjusteDis);
		dataset3 = new XYSeriesCollection();
		dataset3.addSeries(tortuosidadeMed);
		dataset4 = new XYSeriesCollection();
		dataset.addSeries(pontosReconstruidos);
		dataset4.addSeries(retaMelhorAjusteMed);
		this.showGraph(this.largura);
		this.lista2 = new TLista();
		this.lista = new TLista();
		
		imagemRec3d = new boolean[altura][largura][imagemRef.length];
		
		grafico=true;
		for (int i = 0; i < altura; i++) { 
			for (int k = 0; k < imagemRef.length; k++) {

				if( imagemRef[k][i][0] == (byte) 255){
					imagemRec3d[i][0][k] =true;
					lista2.insere(i, 0, k);
				}
				

			}
		}
		d=0;
		t=true;
		while (t&&!Thread.currentThread().isInterrupted()) {

			// bar.setString("Rec: "+d);
			dilata(EE, d);
		
			// IJ.showStatus(" "+d);

			d+=2;

		}
		pontosReconstruidos.fireSeriesChanged();
			

	}

}
