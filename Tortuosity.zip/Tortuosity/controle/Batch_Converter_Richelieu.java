package controle;

import ij.plugin.*;

import java.io.*;

import ij.*;
import ij.process.*;
import ij.gui.*;
import ij.process.ImageProcessor;


public class Batch_Converter_Richelieu implements PlugIn {
	/* Saves the specified image. The format argument must be "tiff",  
    "jpeg", "gif", "zip", "raw", "avi", "bmp", "fits", "pgm", "png", 
    "text image", "lut", "selection" or "xy Coordinates". */

	private static String[] choices = {"TIFF", "JPEG", "GIF", "PNG", "PGM", "BMP", "FITS", "Text Image", "ZIP", "Raw"};
	private static String format = "JPEG";
	private static boolean x_invertido, x_normal, y_inv, y_nor, z_inv, z_nor;
	
	public void run(String arg) {
		String dir1 = IJ.getDirectory("Indique a pasta de origem...");
		if (dir1==null) return;
		if (!showDialog()) return;
		String dir2 = IJ.getDirectory("Selecione a pasta de destino...");
		if (dir2==null) return;
		if (!new File(dir2).exists()) { // Verifica se o diret�rio existe.   
            (new File(dir2)).mkdir();// Cria o diret�rio
            IJ.log("Diret�rio criado: "+dir2);   
        }
		
		try {
			convert(dir1, dir2, format);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	boolean showDialog() {
		GenericDialog gd = new GenericDialog("Modifica��o do Batch Converter (PIBIC)");
		gd.addChoice("Converter para: ", choices, format);
		//gd.addCheckbox("Make Grayscale", convertToGrayscale);
		
		gd.addCheckbox("+x", x_normal);
		gd.addCheckbox("-x", x_invertido);
		gd.addCheckbox("+y", y_nor);
		gd.addCheckbox("-y", y_inv);
		gd.addCheckbox("+z", z_nor);
		gd.addCheckbox("-z", z_inv);
		gd.showDialog();
		
		if (gd.wasCanceled())
			return false;
		
		format = gd.getNextChoice();
	//	convertToGrayscale = gd.getNextBoolean();
		x_normal=gd.getNextBoolean();
		x_invertido=gd.getNextBoolean();
		y_nor=gd.getNextBoolean();
		y_inv=gd.getNextBoolean();
		z_nor=gd.getNextBoolean();
		z_inv=gd.getNextBoolean();
		
		return true;
	}
	
    private static String ajuste(int aux) {

        int i = 1;
        while (aux >= 1) {
            aux /= 10;
            i++;
        }
        return "%0" + i + "d";
    }

	public void convert(String dir1, String dir2, String format) throws IOException {
		
		int[] objetoCamada; 
		 int[] matriz2;
		 int[][] objetoCompleto; 
			objetoCamada = null;
			objetoCompleto = null;

		IJ.log("\\Clear");
		IJ.log("Converting to "+format);
		IJ.log("dir1: "+dir1);
		IJ.log("dir2: "+dir2);
		String[] listaArquivos = new File(dir1).list();
int k2=listaArquivos.length;										// posi��o do array apontar�
		
		ImagePlus imagem = IJ.openImage(dir1+listaArquivos[0]);//listaArquivos[k]));
		imagem.show();
		 /* if (pos > -1) {
		  int pos = listaArquivos[0].getName().lastIndexOf('.');
	       format=listaArquivos[0].getName().substring(pos + 1).toUpperCase();
	    }*/  
	    IJ.log("Tipo: "+ imagem.getType());
		   int w = imagem.getWidth();
		   int h = imagem.getHeight();
	//	   IJ.log("W : "+w+"\nH : "+h);
		   int tipo=0;
		    
		   objetoCompleto = new int[w*h][listaArquivos.length];
		//   IJ.log("W : "+objetoCompleto.length+"\nH : "+objetoCompleto[0].length);
			for (int k = 0; k < listaArquivos.length; k++) { // com essa estrutura
				imagem = IJ.openImage(dir1+listaArquivos[k]);//listaArquivos[k]));
				
				int pixels[]=null;		
				try{
				if (imagem.getType() != ImagePlus.COLOR_RGB){
				    pixels = (int[])imagem.getProcessor().convertToRGB().getPixels();
				  
				   }else{
					 pixels = (int[])imagem.getProcessor().getPixels();
					   
				   }
				}catch(java.lang.NullPointerException e){
					IJ.log("K:"+k);
					IJ.log("Talvez as imagens possuam propriedades diferentes. \nDesculpe o transtorno, um conjunto de verifica��es est� em desenvolvimento.");
					return;
							

			}
				   
				  // IJ.log("problema resolvido");
				   
objetoCamada = pixels; 	
    for (int i = 0; i < (h); i++) {
    	for (int j = 0; j < w; j++) {
    	
					try{
						objetoCompleto[(i*w)+j][k] = objetoCamada[(i*w)+j]; // Posi��o da linha vezes a quantidade de colunas mais a posi��o da linha.
					}catch(ArrayIndexOutOfBoundsException e){
						IJ.log("Erro na abertura!\n i :"+i+" \nj: "+j+"\nk: "+k+" (arquivo)");
						return;
					}
							
				}

			}
	imagem.flush ();

		}
			System.out.println("Tipo :"+tipo);
			objetoCamada=null;
			imagem.flush ();
		IJ.log("Conjunto Carregado");		

		String ajuste, novo;
		String caminho=null;
		ImageProcessor ip2=null;
	       
        if (x_normal) {// "Esquerda para direita"
            caminho = dir2 + "\\Visualiza��o(+x)";

            if (!new File(caminho).exists()) { // Verifica se o diret�rio existe.   
                (new File(caminho)).mkdir();   // Cria o diret�rio   
            }
                 
             matriz2 = new int[h*k2];
            

          
            ajuste = ajuste(w);
            for (int j = w-1, ind = 0; j >= 0; j--, ind++) {
                		
                novo = caminho + "\\Teste(" + (String.format(ajuste, ind)) + ")."+format;; // o numero de zeros a esquerda aina pode variar
             
                for (int i = 0; i < h ; i++) {

                    for (int k = 0; k <k2  ; k++) {
			
                        matriz2[(i*k2)+k] = objetoCompleto[(i*w)+j][(k2-1)-k];
                    }
                }
                imagem=new ImagePlus();  
                ip2 = new ColorProcessor(k2, h, matriz2);//  (k2, h); // of same type  
                
              	imagem.setProcessor(""+ind, ip2);
               	IJ.saveAs(imagem, format, novo);  

				
            }
            IJ.log("+x concluido");
            imagem=null;
				ip2=null;
        }
		
		if (x_invertido) {// "Direita para esquerda"
            caminho = dir2 + "\\Visualiza��o(-x)";
            matriz2 = new int[h*k2];
            IJ.log("aqui01");
           
			IJ.log("aqui 02");
            if (!new File(caminho).exists()) { // Verifica se o diret�rio existe.   
                (new File(caminho)).mkdir();   // Cria o diret�rio   
            }
            ajuste = ajuste(w);
           for (int j = w-1, ind = 0; j >= 0; j--, ind++) {                		
                novo = caminho + "\\Teste(" + (String.format(ajuste, ind)) + ")."+format;; // o numero de zeros a esquerda aina pode variar
               for (int i =0; i < h; i++) {
                   for (int k = 0; k < k2; k++) {
			try{
                        matriz2[(i*k2)+k] = objetoCompleto[(i*w)+j][k];
                       }catch(ArrayIndexOutOfBoundsException e){
                        IJ.log("(i*k2)+k = ("+i+"*"+k2+")"+k);
                        return;
                    }
                    }
                }
               imagem=new ImagePlus();  
               ip2 = new ColorProcessor(k2, h, matriz2);//  (k2, h); // of same type  
              // IJ.log("aqui 03");
              // 	ip2.setPixels(matriz2);
   				imagem.setProcessor(""+ind, ip2);
               
   				IJ.saveAs(imagem, format, novo);  

          
            }
           IJ.log("-x concluido");
           imagem=null;
				ip2=null;
        }


         
        if (y_nor) { // "Superior"
            caminho = dir2 + "\\Visualiza��o(+y)";

            if (!new File(caminho).exists()) { // Verifica se o diret�rio existe.   
                (new File(caminho)).mkdir();   // Cria o diret�rio   
            }
                
            matriz2 = new int[k2*w];
            //imagem= new BufferedImage( w,k2, tipo);
          //  imagem=new ImagePlus();  
           // ip2 = imagem.getProcessor().createProcessor(w, k2); // of same type  
    		
            ajuste = ajuste(h);
            for (int i = 0, ind = 0; i <h; i++, ind++) {
                novo = caminho + "\\Teste(" + (String.format(ajuste, ind)) + ")."+format;; // o numero de zeros a esquerda aina pode variar
                
                for (int k = 0; k <k2; k++) {

		
                    for (int j = 0; j < w; j++) {
                
                        matriz2[(k*w)+j] = objetoCompleto[(i*w)+j][(k2-1)-k];
                    }
                }
                imagem=new ImagePlus();  
                ip2 = new ColorProcessor(w, k2, matriz2);//  (k2, h); // of same type  
            	imagem.setProcessor(""+ind, ip2);
               	IJ.saveAs(imagem, format, novo);  
    }
            imagem=null;
        	ip2=null;
        	IJ.log("+y concluido");
        }
        if (y_inv) {// "inferior"
            caminho = dir2 + "\\Visualiza��o(-y)";

            if (!new File(caminho).exists()) { // Verifica se o diret�rio existe.   
                (new File(caminho)).mkdir();   // Cria o diret�rio   
            }
                
             matriz2 = new int[k2*w];
       //     imagem= new BufferedImage( w,k2, tipo);
        //     imagem=new ImagePlus();  
        //     ip2 = imagem.getProcessor().createProcessor(w, k2); // of same type
		
            ajuste = ajuste(h);
             for (int i = h-1, ind = 0; i >=0; i--, ind++) {
                novo = caminho + "\\Teste(" + (String.format(ajuste, ind)) + ")."+format; // o numero de zeros a esquerda aina pode variar
                
                for (int k = 0; k <k2; k++){

		
                    for (int j = 0; j < w; j++) {
                
                       matriz2[(k*w)+j] = objetoCompleto[(i*w)+j][k];
                    }
                }
                 //imagem.setRGB(0, 0, w, k2, matriz2, 0, w);
                imagem=new ImagePlus();  
                ip2 = new ColorProcessor(w, k2, matriz2);//  (k2, h); // of same type  
            	imagem.setProcessor(""+ind, ip2);
               	IJ.saveAs(imagem, format, novo);  
             }
             IJ.log("-y concluido");
             imagem=null;
         	ip2=null;
        }
         if(z_nor) {		// "Anterior",
            caminho = dir2 + "\\Visualiza��o(+z)";

            if (!new File(caminho).exists()) { // Verifica se o diret�rio existe.   
                (new File(caminho)).mkdir();   // Cria o diret�rio   
            }

            matriz2 = new int[h*w];
         //   imagem= new BufferedImage( w,h, tipo);
          //  imagem=new ImagePlus();  
           // ip2 = imagem.getProcessor().createProcessor(w, h); // of same type 
            ajuste = ajuste(k2);
            for (int k = 0, ind = 0; k < k2; k++, ind++) {

              
                novo = caminho + "\\Teste(" + (String.format(ajuste, ind)) + ")."+format; // o numero de zeros a esquerda aina pode variar
               
            
                for (int i = 0; i < h; i++) {
                
                    for (int j = 0; j < w; j++) {
                    
                        matriz2[(i*w)+j] = objetoCompleto[(i*w)+j][k];
                    }
                }
                imagem=new ImagePlus();  
                ip2 = new ColorProcessor(w, h, matriz2);//  (k2, h); // of same type  
            	imagem.setProcessor(""+ind, ip2);
               	IJ.saveAs(imagem, format, novo);  
    }
            IJ.log("+z concluido");
            imagem=null;
        	ip2=null;
        }
        if (z_inv) {			// "Posterior"

            caminho = dir2 + "\\Visualiza��o(-z)";

            if (!new File(caminho).exists()) { // Verifica se o diret�rio existe.   
                (new File(caminho)).mkdir();   // Cria o diret�rio   
            }
                
           
            matriz2 = new int[h*w];
            //imagem= new BufferedImage( w,h, tipo);
    //        imagem=new ImagePlus();  
     //       ip2 = imagem.getProcessor().createProcessor(w, h); // of same type 
            
            
            ajuste = ajuste(k2);
            
            //ajuste = ajuste(listaArquivos.length - 1);
            for (int k = k2 - 1, ind = 0; k >= 0; k--, ind++) {

                novo = caminho + "\\Teste(" + (String.format(ajuste, ind)) + ")."+format; // o numero de zeros a esquerda aina pode variar
                
                for (int i = 0; i < h; i++) {
                
                    for (int j = 0; j < w; j++) {
                    
                        matriz2[(i*w)+j] = objetoCompleto[(i*w)+(w- 1) - j][k];
                    }
                }
         //         imagem.setRGB(0, 0, w, h, matriz2, 0, w);
                imagem=new ImagePlus();  
                ip2 = new ColorProcessor(w, h, matriz2);//  (k2, h); // of same type  
            	imagem.setProcessor(""+ind, ip2);
               	IJ.saveAs(imagem, format, novo);  
        }
        	ip2=null;
imagem=null;
IJ.log("-z Concluido");
        }



    
       IJ.log("Fim");

       IJ.showStatus(6+" / "+6);
		
	}
	
public void convert(byte objetoCompleto[][],int altura, int largura) throws IOException {
	 ImagePlus imagem;
		
		 byte[] matriz2;
		 
			int tam=objetoCompleto.length;
		ColorProcessor novoColorP;
		x_normal=true;
		x_invertido=true;
		y_nor=true;
		y_inv=true;
		z_nor=true;
		z_inv=true;
			
		
		String ajuste, novo;
		String caminho=null;
		//ImageProcessor novoColorP=null;
		String dir2 = IJ.getDirectory("Onde salvar?");
        if (x_normal) {// "Esquerda para direita"
            caminho = dir2 + "\\Visualiza��o(+x)";

            if (!new File(caminho).exists()) { // Verifica se o diret�rio existe.   
                (new File(caminho)).mkdir();   // Cria o diret�rio   
            }
                 
             matriz2 = new byte[altura*tam];
            

          
            ajuste = ajuste(largura);
            for (int j = 0, ind = 0; j < largura; j++, ind++) {
                		
                novo = caminho + "\\Teste(" + (String.format(ajuste, ind)) + ")."+format;; // o numero de zeros a esquerda aina pode variar
             
                for (int i = 0; i < altura ; i++) {

                    for (int k = 0; k <tam  ; k++) {
			try{
                        matriz2[(i*tam)+k] =objetoCompleto[k][(i*largura)+j];
			}catch(Exception e){
				e.printStackTrace();
				System.out.println(i +" "+j+" "+ k);
				return;
			}
			}
                }
                ByteProcessor ip2=new ByteProcessor(tam, altura);
                ip2.setPixels(matriz2);
                imagem= new ImagePlus("A New Image", ip2);

               	IJ.saveAs(imagem, format, novo);  

				
            }
        
            IJ.log("+x concluido");
           
        }
        
		if (x_invertido) {// "Direita para esquerda"
            caminho = dir2 + "\\Visualiza��o(-x)";
            matriz2 = new byte[altura*tam];
           
            if (!new File(caminho).exists()) { // Verifica se o diret�rio existe.   
                (new File(caminho)).mkdir();   // Cria o diret�rio   
            }
            ajuste = ajuste(largura);
           for (int j = largura-1, ind = 0; j >= 0; j--, ind++) {                		
                novo = caminho + "\\Teste(" + (String.format(ajuste, ind)) + ")."+format;; // o numero de zeros a esquerda aina pode variar
               for (int i =0; i < altura; i++) {
                   for (int k = 0; k < tam; k++) {
			
                        matriz2[(i*tam)+k] =  objetoCompleto[k][(i*largura)+j];
                     
                    }
                }
           ByteProcessor ip2=new ByteProcessor(tam, altura);
                ip2.setPixels(matriz2);
                imagem= new ImagePlus("A New Image", ip2);

               	IJ.saveAs(imagem, format, novo);  
          
            }
           IJ.log("-x concluido");
           imagem=null;
				novoColorP=null;
        }


         
        if (y_nor) { // "Superior"
            caminho = dir2 + "\\Visualiza��o(+y)";

            if (!new File(caminho).exists()) { // Verifica se o diret�rio existe.   
                (new File(caminho)).mkdir();   // Cria o diret�rio   
            }
                
            matriz2 = new byte[tam*largura];
          
            ajuste = ajuste(altura);
            for (int i = 0, ind = 0; i <altura; i++, ind++) {
                novo = caminho + "\\Teste(" + (String.format(ajuste, ind)) + ")."+format;; // o numero de zeros a esquerda aina pode variar
                
                for (int k = 0; k <tam; k++) {

		
                    for (int j = 0; j < largura; j++) {
                
                        matriz2[(k*largura)+j] = objetoCompleto[k][(i*largura)+j];
                    }
                }
                    	  ByteProcessor ip2=new ByteProcessor(largura, tam);
                ip2.setPixels(matriz2);
                imagem= new ImagePlus("A New Image", ip2);

               	IJ.saveAs(imagem, format, novo);  
    }
          IJ.log("+y concluido");
        }
        if (y_inv) {// "inferior"
            caminho = dir2 + "\\Visualiza��o(-y)";

            if (!new File(caminho).exists()) { // Verifica se o diret�rio existe.   
                (new File(caminho)).mkdir();   // Cria o diret�rio   
            }
                
             matriz2 = new byte[tam*largura];
      
          ajuste = ajuste(altura);
             for (int i = altura-1, ind = 0; i >=0; i--, ind++) {
                novo = caminho + "\\Teste(" + (String.format(ajuste, ind)) + ")."+format; // o numero de zeros a esquerda aina pode variar
                
                for (int k = 0; k <tam; k++){

		
                    for (int j = 0; j < largura; j++) {
                
                       matriz2[(k*largura)+j] = objetoCompleto[k][(i*largura)+j];
                    }
                }
                    	  ByteProcessor ip2=new ByteProcessor(largura, tam);
                ip2.setPixels(matriz2);
                imagem= new ImagePlus("A New Image", ip2);

               	IJ.saveAs(imagem, format, novo);  
             }
             IJ.log("-y concluido");
         }
         if(z_nor) {		// "Anterior",
            caminho = dir2 + "\\Visualiza��o(+z)";

            if (!new File(caminho).exists()) { // Verifica se o diret�rio existe.   
                (new File(caminho)).mkdir();   // Cria o diret�rio   
            }

            matriz2 = new byte[altura*largura];
            ajuste = ajuste(tam);
            for (int k = 0, ind = 0; k < tam; k++, ind++) {

              
                novo = caminho + "\\Teste(" + (String.format(ajuste, ind)) + ")."+format; // o numero de zeros a esquerda aina pode variar
               
            
                for (int i = 0; i < altura; i++) {
                
                    for (int j = 0; j < largura; j++) {
                    
                        matriz2[(i*largura)+j] = objetoCompleto[k][(i*largura)+j];
                    }
                }
                  	  ByteProcessor ip2=new ByteProcessor(largura, altura);
                ip2.setPixels(matriz2);
                imagem= new ImagePlus("A New Image", ip2);

               	IJ.saveAs(imagem, format, novo);  
    }
            IJ.log("+z concluido");
            
               }
        if (z_inv) {			// "Posterior"

            caminho = dir2 + "\\Visualiza��o(-z)";

            if (!new File(caminho).exists()) { // Verifica se o diret�rio existe.   
                (new File(caminho)).mkdir();   // Cria o diret�rio   
            }
                
           
            matriz2 = new byte[altura*largura];
            
            
            ajuste = ajuste(tam);
            
            //ajuste = ajuste(listaArquivos.length - 1);
            for (int k = tam - 1, ind = 0; k >= 0; k--, ind++) {

                novo = caminho + "\\Teste(" + (String.format(ajuste, ind)) + ")."+format; // o numero de zeros a esquerda aina pode variar
                
                for (int i = 0; i < altura; i++) {
                
                    for (int j = 0; j < largura; j++) {
                    
                        matriz2[(i*largura)+j] = objetoCompleto[k][(i*largura)+(largura- 1) - j];
                    }
                }
                           	  ByteProcessor ip2=new ByteProcessor(largura, altura);
                ip2.setPixels(matriz2);
                imagem= new ImagePlus("A New Image", ip2);

               	IJ.saveAs(imagem, format, novo);
        }
        	
IJ.log("-z Concluido");
        }



    
       IJ.log("Fim");

       IJ.showStatus(6+" / "+6);
		
	}

	/** This is the place to add code to process each image. The image 
		is not written if this method returns null. */
	/*public ImagePlus process(ImagePlus img) {
		double scale = 0.5;
		int width = img.getWidth();
		int height = img.getHeight();
		//ImageProcessor ip = img.getProcessor();
		//ip.setInterpolate(true);
		//ip = ip.resize((int)(width*scale), (int)(height*scale));
		//img.setProcessor(null, ip);
		return img;
	}*/

	
	/**	Run Batch_Converter using a command something like
			"java -cp ij.jar;. Batch_Converter_Richelieu c:\dir1\ c:\dir2\ "
		or (Unix)
			"java -cp ij.jar:. Batch_Converter_Richelieu /users/wayne/dir1 /users/wayne/dir2/" 
	*/
	public static void main(String args[]) {
		if (args.length<2)
			IJ.log("usage: java Batch_Converter_Richelieu srcdir dstdir");
		else {
			try {
				new Batch_Converter_Richelieu().convert(args[0], args[1], "Jpeg");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.exit(0);
		}
	}

}

