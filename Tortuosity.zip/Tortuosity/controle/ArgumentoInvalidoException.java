package controle;



public class ArgumentoInvalidoException extends MinhaException {
	public ArgumentoInvalidoException(String m) {
		super(m);
	}
}