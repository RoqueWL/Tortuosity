package controle;

import ij.IJ;
import janelas.Janela_2;



public class ThreadCalcular extends Thread {
	
Imagem direcao;	
int numTab;
int EE;

	

	public ThreadCalcular(Imagem direcao, int numTab, int EE){
		this.numTab=numTab;
		this.direcao=direcao;
		this.EE=EE;
		
	}
	
	public void run(){
		long lStartTime = System.currentTimeMillis();
		//some tasks
		boolean abt=direcao.reconstr(EE, this);
			if(abt){
				IJ.log("Dire��o abortada");
				direcao=null;
				return;
			}
		//direcao.calcularTortuosidade();
		//direcao.exibeText();
		long lEndTime = System.currentTimeMillis();
		 
		long difference = lEndTime - lStartTime;
		direcao.bar.setString(direcao.bar.getString()+" in "+difference+" ms");
		//System.out.println("Elapsed milliseconds: " + difference);
	
		direcao.enabledTab(numTab, difference);
		direcao.tabela.setModel(new TabelaAbas(direcao));
		Janela_2.getInstance().threadCalcularFinalizou();
		direcao=null;
	}

}
